"""Read-only access to the NERDC-approved Nigerian subject catalogue."""

import json
from pathlib import Path
from typing import Iterable, Optional


CATALOGUE_PATH = (
    Path(__file__).resolve().parent
    / "data"
    / "catalogues"
    / "nerdc_nigeria_approved_subjects.json"
)

# Preserve persisted/profile values while exposing the PDF's canonical fields.
STREAM_TO_FIELD = {
    "Science": "Science",
    "Business": "Business",
    "Commercial": "Business",
    "Humanities": "Humanities",
    "Arts": "Humanities",
}
FIELD_TO_STREAMS = {
    "Science": {"Science"},
    "Business": {"Business", "Commercial"},
    "Humanities": {"Humanities", "Arts"},
}
CATALOGUE_TO_CURRICULUM_SUBJECTS = {
    "English Studies": {"English Studies", "English Language"},
    "General Mathematics": {"General Mathematics", "Mathematics"},
    "Accounting": {"Accounting", "Financial Accounting"},
    "Literature in English": {"Literature in English", "Literature-in-English"},
}


def load_nerdc_catalogue(path: Path = CATALOGUE_PATH) -> dict:
    with path.open("r", encoding="utf-8") as catalogue_file:
        return json.load(catalogue_file)


def build_nerdc_subject_response(
    country: str,
    class_level: str,
    chunks: Iterable,
    stream: Optional[str] = None,
    catalogue: Optional[dict] = None,
) -> dict:
    """Return approved entries and indicate whether matching lesson chunks exist."""
    catalogue = catalogue or load_nerdc_catalogue()
    response = {
        "country": country,
        "class_level": class_level,
        "stream": stream,
        "subjects": [],
    }
    if country != "Nigeria":
        return response

    band = next(
        (entry for entry in catalogue["level_bands"] if class_level in entry["class_levels"]),
        None,
    )
    if band is None:
        return response

    selected_field = STREAM_TO_FIELD.get(stream) if stream else None
    matching_chunks = [
        chunk for chunk in chunks
        if chunk.country == country and chunk.class_level == class_level
    ]

    for subject in band["subjects"]:
        field = subject.get("field")
        if selected_field and field and field != selected_field:
            continue
        curriculum_subject_names = CATALOGUE_TO_CURRICULUM_SUBJECTS.get(
            subject["name"], {subject["name"]}
        )

        if field:
            allowed_streams = FIELD_TO_STREAMS[field]
            has_content = any(
                chunk.subject in curriculum_subject_names
                and (chunk.stream is None or chunk.stream in allowed_streams)
                for chunk in matching_chunks
            )
        else:
            has_content = any(
                chunk.subject in curriculum_subject_names for chunk in matching_chunks
            )

        response["subjects"].append({
            **subject,
            "content_available": has_content,
            "content_status": "available" if has_content else "not_yet_verified",
        })

    return response