"""
Persistent per-learner mastery model.

This is a deliberately simple starting point: mastery per topic is a
float between 0 and 1, nudged up on correct answers and down on
incorrect ones. This is a stand-in for the Bayesian/Deep Knowledge
Tracing model described in the reference architecture (Section 3.3);
swapping in a real BKT/DKT implementation later does not require
changing any other part of this codebase, since everything else only
calls get_mastery() / update_mastery().

Storage: a single JSON file per learner under app/data/learners/.
This is intentionally file-based, not a database, to keep the
prototype runnable with zero infrastructure setup. Swap for
PostgreSQL (Section 3, Data/Knowledge layer) for a real deployment.
"""

import json
import os
from datetime import datetime, timezone


class LearnerModel:
    def __init__(self, learner_id: str, storage_dir: str):
        self.learner_id = learner_id
        self.storage_dir = storage_dir
        os.makedirs(storage_dir, exist_ok=True)
        self.path = os.path.join(storage_dir, f"{learner_id}.json")
        self._data = self._load()

    def _load(self) -> dict:
        if os.path.exists(self.path):
            with open(self.path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {
            "learner_id": self.learner_id,
            "class_level": None,
            "mastery": {},   # topic -> float in [0, 1]
            "history": [],   # list of interaction log entries
        }

    def _save(self):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2)

    def set_class_level(self, class_level: str):
        self._data["class_level"] = class_level
        self._save()

    def get_class_level(self):
        return self._data.get("class_level")

    def get_mastery(self, topic: str) -> float:
        return self._data["mastery"].get(topic, 0.3)  # start slightly below neutral

    def update_mastery(self, topic: str, correct: bool):
        current = self.get_mastery(topic)
        step = 0.15
        if correct:
            new_value = min(1.0, current + step)
        else:
            new_value = max(0.0, current - step * 0.6)  # penalize less than we reward
        self._data["mastery"][topic] = round(new_value, 3)
        self._data["history"].append({
            "topic": topic,
            "correct": correct,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })
        self._save()
        return new_value

    def update_subject_mastery(self, subject: str, topic: str, correct: bool):
        """Record a per-student, per-subject attempt without merging same-named topics."""
        subject = (subject or 'Unspecified').strip()
        topic = (topic or 'General').strip()
        key = f'{subject}::{topic}'
        previous = self._data.setdefault('subject_mastery', {}).get(key, 0.3)
        updated = min(1.0, previous + 0.15) if correct else max(0.0, previous - 0.09)
        updated = round(updated, 3)
        self._data['subject_mastery'][key] = updated
        self._data['mastery'][topic] = updated  # legacy session-plan compatibility
        self._data['history'].append({'subject': subject, 'topic': topic, 'correct': bool(correct),
                                      'timestamp': datetime.now(timezone.utc).isoformat()})
        self._save()
        return updated

    def subject_progress(self, available_subjects=None):
        subjects = {}
        for subject in available_subjects or []:
            subjects[subject] = {'subject': subject, 'attempts': 0, 'correct': 0, 'mastery_percent': 0}
        for event in self._data.get('history', []):
            subject = event.get('subject')
            if not subject: continue  # historical unlabelled attempts cannot be attributed reliably
            item = subjects.setdefault(subject, {'subject': subject, 'attempts': 0, 'correct': 0, 'mastery_percent': 0})
            item['attempts'] += 1
            item['correct'] += int(bool(event.get('correct')))
        for subject, item in subjects.items():
            values = [v for k,v in self._data.get('subject_mastery', {}).items() if k.startswith(subject+'::')]
            item['mastery_percent'] = round(sum(values)/len(values)*100) if values else 0
        return {'learner_id': self.learner_id, 'subjects': sorted(subjects.values(),key=lambda x:x['subject'].lower()),
                'note': 'Legacy practice without a subject cannot be reliably assigned to a subject.'}

    def record_study(self, subject: str, topic: str, kind: str = 'lesson'):
        subject = (subject or 'Unspecified').strip()
        topic = (topic or 'General').strip()
        self._data.setdefault('study_history', []).append({
            'subject': subject, 'topic': topic, 'kind': kind,
            'timestamp': datetime.now(timezone.utc).isoformat(),
        })
        self._save()

    def activity_summary(self):
        study = self._data.get('study_history', [])
        assessed = [x for x in self._data.get('history', []) if x.get('subject')]
        studied = {(x['subject'], x['topic']) for x in study}
        mastered = {tuple(key.split('::', 1)) for key, value in
                    self._data.get('subject_mastery', {}).items() if value >= 0.7}
        recent = ([{**x, 'type': 'assessment'} for x in assessed] +
                  [{**x, 'type': x.get('kind', 'lesson')} for x in study])
        recent.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        return {'learner_id': self.learner_id, 'topics_studied': len(studied),
                'assessments_taken': len(assessed),
                'average_score': round(100 * sum(bool(x.get('correct')) for x in assessed) / len(assessed)) if assessed else 0,
                'topics_mastered': len(mastered), 'recent_activity': recent[:15]}

    def summary(self) -> dict:
        return {
            "learner_id": self.learner_id,
            "class_level": self.get_class_level(),
            "mastery": self._data["mastery"],
            "num_interactions": len(self._data["history"]),
        }
