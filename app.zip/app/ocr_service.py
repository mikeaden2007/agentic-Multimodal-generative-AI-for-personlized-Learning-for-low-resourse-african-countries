"""Text extraction for supported image, PDF, DOCX, and TXT uploads."""
from __future__ import annotations

import io
import os
import shutil
import zipfile
from pathlib import Path

import pymupdf as fitz
import pytesseract
from docx import Document
from docx.opc.exceptions import PackageNotFoundError
from PIL import Image, ImageOps, UnidentifiedImageError

MAX_UPLOAD_BYTES = 20 * 1024 * 1024
MAX_IMAGE_BYTES = 12 * 1024 * 1024
MAX_PIXELS = 24_000_000
MAX_PDF_PAGES = 20
MAX_DOCX_UNPACKED_BYTES = 50 * 1024 * 1024
MAX_DOCX_ENTRIES = 2_000
SUPPORTED_IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff', '.webp', '.gif'}
Image.MAX_IMAGE_PIXELS = MAX_PIXELS


class OCRUnavailableError(RuntimeError):
    """OCR engine or its English language data is unavailable."""


def find_tesseract(env=None, which=None, candidates=None):
    """Resolve Tesseract from an override, PATH, or standard Windows paths."""
    env = os.environ if env is None else env
    which = shutil.which if which is None else which
    custom = env.get('TESSERACT_CMD', '').strip().strip('"')
    if custom and Path(custom).is_file():
        return custom
    path_result = which('tesseract')
    if path_result:
        return path_result
    candidates = candidates if candidates is not None else [
        r'C:\Program Files\Tesseract-OCR\tesseract.exe',
        r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
    ]
    for path in candidates:
        if path and Path(path).is_file():
            return str(path)
    return None


def _configure_engine():
    path = find_tesseract()
    if path:
        pytesseract.pytesseract.tesseract_cmd = path
        return path
    raise OCRUnavailableError(
        'Tesseract OCR is not installed or was not found. Install Tesseract, '
        'then restart the backend. On Windows, the default installation at '
        r'C:\Program Files\Tesseract-OCR\tesseract.exe is detected automatically. '
        'For another location, set TESSERACT_CMD and check /health.'
    )


def _ensure_english():
    cmd = _configure_engine()
    try:
        languages = pytesseract.get_languages(config='')
    except (pytesseract.TesseractError, pytesseract.TesseractNotFoundError, OSError) as exc:
        raise OCRUnavailableError(
            'Tesseract was found but its language data cannot be loaded. '
            'Check TESSDATA_PREFIX and your tessdata folder. '
            'The folder must contain eng.traineddata. Check /health. Details: ' + str(exc)
        ) from exc
    if 'eng' not in languages:
        raise OCRUnavailableError(
            'English OCR data (eng.traineddata) is missing. Install the English '
            'language data in the Tesseract tessdata folder. If TESSDATA_PREFIX '
            'is set, verify it points to the correct tessdata location. Check /health.'
        )
    return cmd, languages


def tesseract_status() -> dict:
    try:
        cmd, languages = _ensure_english()
        return {'available': True, 'engine': cmd, 'english_available': True}
    except OCRUnavailableError as exc:
        return {'available': False, 'english_available': False, 'message': str(exc)}


def _ocr_image(image: Image.Image) -> str:
    try:
        return pytesseract.image_to_string(image, lang='eng', config='--psm 3', timeout=25).strip()
    except RuntimeError as exc:
        raise OCRUnavailableError('OCR timed out. Try a smaller, clearer image or PDF.') from exc
    except (pytesseract.TesseractError, pytesseract.TesseractNotFoundError, OSError) as exc:
        raise OCRUnavailableError('Tesseract failed while reading the upload: ' + str(exc)) from exc


def extract_text_from_image(image_bytes: bytes) -> str:
    if not image_bytes:
        raise ValueError('The uploaded file is empty.')
    if len(image_bytes) > MAX_IMAGE_BYTES:
        raise ValueError('Image is too large. Maximum size is 12 MB.')
    try:
        with Image.open(io.BytesIO(image_bytes)) as source:
            if source.format not in {'PNG', 'JPEG', 'BMP', 'TIFF', 'WEBP', 'GIF'}:
                raise ValueError('Unsupported format. Upload a PNG, JPG, WEBP, BMP, TIFF or GIF image.')
            if source.width * source.height > MAX_PIXELS:
                raise ValueError('Image dimensions are too large. Try a smaller image.')
            source.seek(0)
            image = ImageOps.exif_transpose(source).convert('RGB')
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        raise ValueError('Cannot open this file as an image. Please use PNG, JPG, WEBP, BMP, TIFF or GIF.') from exc

    _ensure_english()
    return _ocr_image(image)


def _extract_text_from_pdf(upload_bytes: bytes) -> str:
    try:
        document = fitz.open(stream=upload_bytes, filetype='pdf')
    except (fitz.FileDataError, RuntimeError, ValueError) as exc:
        raise ValueError('Cannot open this file as a PDF or image. Upload a valid PDF, DOCX, TXT, or supported image.') from exc

    with document:
        if document.page_count > MAX_PDF_PAGES:
            raise ValueError(f'PDF has too many pages. Maximum is {MAX_PDF_PAGES} pages.')

        page_texts = []
        tesseract_ready = False
        for page in document:
            text = page.get_text('text').strip()
            if not text:
                if not tesseract_ready:
                    _ensure_english()
                    tesseract_ready = True
                width, height = page.rect.width, page.rect.height
                scale = min(2.0, (MAX_PIXELS / max(width * height, 1)) ** 0.5)
                pixmap = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
                with Image.open(io.BytesIO(pixmap.tobytes('png'))) as rendered:
                    text = _ocr_image(rendered.convert('RGB'))
            page_texts.append(text)
        return '\n\n'.join(text for text in page_texts if text)


def _extract_text_from_docx(upload_bytes: bytes) -> str:
    try:
        with zipfile.ZipFile(io.BytesIO(upload_bytes)) as archive:
            entries = archive.infolist()
            if len(entries) > MAX_DOCX_ENTRIES:
                raise ValueError(f'DOCX contains too many files. Maximum is {MAX_DOCX_ENTRIES}.')
            if sum(entry.file_size for entry in entries) > MAX_DOCX_UNPACKED_BYTES:
                raise ValueError('DOCX contents are too large to process safely.')
        document = Document(io.BytesIO(upload_bytes))
    except ValueError:
        raise
    except (zipfile.BadZipFile, PackageNotFoundError, KeyError, OSError) as exc:
        raise ValueError('Cannot open this DOCX file. Upload a valid Word document.') from exc

    content = [paragraph.text for paragraph in document.paragraphs if paragraph.text.strip()]
    for table in document.tables:
        for row in table.rows:
            content.append('\t'.join(cell.text for cell in row.cells))
    return '\n'.join(content).strip()


def _extract_text_from_txt(upload_bytes: bytes) -> str:
    for encoding in ('utf-8-sig', 'utf-16', 'utf-8', 'cp1252', 'latin-1'):
        try:
            return upload_bytes.decode(encoding).strip()
        except UnicodeDecodeError:
            continue
    raise ValueError('Cannot decode this TXT file. Save it as UTF-8 or UTF-16 and try again.')


def extract_text_from_upload(upload_bytes: bytes, filename: str = '') -> str:
    """Extract text from an uploaded image, PDF, DOCX, or TXT document."""
    if not upload_bytes:
        raise ValueError('The uploaded file is empty.')
    if len(upload_bytes) > MAX_UPLOAD_BYTES:
        raise ValueError('File is too large. Maximum upload size is 20 MB.')

    extension = Path(filename).suffix.lower()
    if extension in SUPPORTED_IMAGE_EXTENSIONS:
        return extract_text_from_image(upload_bytes)
    if extension == '.pdf':
        return _extract_text_from_pdf(upload_bytes)
    if extension == '.docx':
        return _extract_text_from_docx(upload_bytes)
    if extension == '.txt':
        return _extract_text_from_txt(upload_bytes)
    if not extension:
        try:
            return extract_text_from_image(upload_bytes)
        except ValueError as exc:
            raise ValueError('Unsupported file type. Upload PNG/JPG, PDF, DOCX, or TXT.') from exc
    raise ValueError('Unsupported file type. Upload PNG/JPG, PDF, DOCX, or TXT.')
