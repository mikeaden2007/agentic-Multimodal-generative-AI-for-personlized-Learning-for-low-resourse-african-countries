"""Low-cost, auditable agent orchestration: no additional model instance required."""
from datetime import datetime, timezone

LOW_MASTERY = 0.55
TARGET_MASTERY = 0.70


def decide_after_assessment(learner, subject, topic, correct, mastery):
    """Observe -> plan -> act (queue student-approved task) -> evaluate on next attempt."""
    subject, topic = (subject or 'General').strip(), (topic or 'General').strip()
    plans = learner._data.setdefault('agent_plans', {})
    key = f'{subject}::{topic}'
    previous = plans.get(key)
    if mastery < LOW_MASTERY:
        action = 'remedial_lesson'
        reason = f'Mastery is {mastery:.0%}, below the {LOW_MASTERY:.0%} revision threshold.'
        steps = ['Review the curriculum lesson and worked examples', 'Complete targeted practice questions', 'Reassess this topic']
        status = 'recommended'
    elif mastery < TARGET_MASTERY:
        action = 'targeted_practice'
        reason = f'Mastery is {mastery:.0%}; further practice is recommended before advancing.'
        steps = ['Complete targeted practice questions', 'Reassess this topic']
        status = 'recommended'
    else:
        action = 'advance'
        reason = f'Mastery is {mastery:.0%}, meeting the {TARGET_MASTERY:.0%} progression threshold.'
        steps = ['Continue to the next curriculum topic']
        status = 'recommended'
    # The new assessment is the evaluation of any earlier intervention.
    evaluation = None
    if previous and previous.get('status') in ('accepted', 'completed'):
        evaluation = {'previous_mastery': previous.get('mastery'), 'new_mastery': mastery,
                      'improved': mastery > previous.get('mastery', mastery)}
    now = datetime.now(timezone.utc).isoformat()
    plan = {'subject': subject, 'topic': topic, 'action': action, 'reason': reason,
            'steps': steps, 'mastery': mastery, 'status': status, 'updated_at': now,
            'evaluation': evaluation, 'requires_student_approval': True}
    plans[key] = plan
    log = learner._data.setdefault('agent_decisions', [])
    log.append({'timestamp': now, 'agent': 'Coordinator Agent', 'observation':
                f'{"Correct" if correct else "Incorrect"} answer in {subject} / {topic}; mastery {mastery:.0%}',
                'delegated_to': ['Progress Agent', 'Planning Agent'], 'action': action,
                'reason': reason, 'result': 'Plan queued for student approval', 'evaluation': evaluation})
    learner._data['agent_decisions'] = log[-100:]
    learner._save()
    return plan


def student_action(learner, subject, topic, action):
    key = f'{subject}::{topic}'
    plan = learner._data.get('agent_plans', {}).get(key)
    if not plan:
        return None
    plan['status'] = {'accept': 'accepted', 'skip': 'skipped', 'complete': 'completed'}[action]
    learner._data.setdefault('agent_decisions', []).append({
        'timestamp': datetime.now(timezone.utc).isoformat(), 'agent': 'Coordinator Agent',
        'observation': 'Student selected ' + action, 'delegated_to': [],
        'action': plan['action'], 'reason': 'Student-controlled learning workflow',
        'result': plan['status']})
    learner._data['agent_decisions'] = learner._data['agent_decisions'][-100:]
    learner._save()
    return plan
