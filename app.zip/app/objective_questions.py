"""Resilient curriculum-grounded objective question generation for small offline LLMs."""
import json
import re
import hashlib


def _extract_json(raw):
    raw = re.sub(r'^```(?:json)?\s*|\s*```$', '', str(raw or '').strip(), flags=re.I)
    for match in re.finditer(r'\{', raw):
        try:
            return json.JSONDecoder().raw_decode(raw[match.start():])[0]
        except (ValueError, TypeError):
            continue
    return {}


def parse_or_fallback(raw, chunks, topic):
    data = _extract_json(raw)
    if isinstance(data, dict):
        opts = data.get('options')
        try:
            correct = int(data.get('correct_index'))
        except (TypeError, ValueError):
            correct = -1
        if (isinstance(opts, list) and len(opts) == 4 and
            all(isinstance(x, str) and 1 <= len(x.strip()) <= 250 for x in opts) and
            len(set(x.strip().casefold() for x in opts)) == 4 and
            0 <= correct < 4 and isinstance(data.get('question'), str) and
            len(data['question'].strip()) >= 8):
            return {'question':data['question'].strip(), 'options':[x.strip() for x in opts],
                    'correct_index':correct, 'explanation':str(data.get('explanation') or
                    'This option is supported by the lesson material.')}
    # No invented answer: use an actual sentence from the retrieved curriculum as
    # the correct option and explicit false meta-statements as distractors.
    texts = [str(getattr(c, 'text', '')).strip() for c in chunks]
    sentences = [v.strip() for t in texts for v in re.split(r'(?<=[.!?])\s+', t)
                 if 40 <= len(v.strip()) <= 210 and v.strip().endswith(('.', '!', '?'))]
    if not sentences:
        sentences = [t[:200].strip() for t in texts if len(t.strip()) >= 25]
    if not sentences:
        raise ValueError('No usable curriculum text for objective question.')
    correct_sentence = sentences[0]
    wrong = ['The lesson states that this topic has no definitions or key ideas.',
             'The lesson states that all the concepts in this topic are unrelated.',
             'The lesson states that there is no information to learn about this topic.']
    index = int(hashlib.sha256((topic + correct_sentence).encode()).hexdigest()[:2], 16) % 4
    options = wrong.copy()
    options.insert(index, correct_sentence)
    return {'question':f'Which statement is supported by the lesson on {topic}?',
            'options':options, 'correct_index':index,
            'explanation':'The correct statement comes directly from the verified lesson: '+correct_sentence}
