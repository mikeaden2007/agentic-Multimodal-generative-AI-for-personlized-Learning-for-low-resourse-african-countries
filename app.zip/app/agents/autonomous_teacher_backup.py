"""Persistent, curriculum-grounded, teacher-led state machine.
The coordinator delegates lesson retrieval, explanation, questioning, evaluation,
and progress updates. Only reviewed offline lessons are used. One shared LLM.
"""
from datetime import datetime, timezone
import re


def teacher_step(learner, user, message, list_lessons, load_lesson, tutor, llm, selected_subject=None):
    sessions = learner._data.setdefault('teacher_subject_sessions', {})
    progress = learner._data.setdefault('teacher_topic_progress', {})
    selected_subject = (selected_subject or '').strip()
    state = sessions.setdefault(selected_subject, {'phase': 'select_lesson', 'lesson_index': 0, 'attempts': 0}) if selected_subject else learner._data.setdefault('teacher_session', {'phase': 'intro', 'lesson_index': 0, 'attempts': 0})
    trace = learner._data.setdefault('teacher_decisions', [])
    message = (message or '').strip()[:2000]
    now = datetime.now(timezone.utc).isoformat()

    def record(agent, action, reason):
        trace.append({'time': now, 'agent': agent, 'action': action, 'reason': reason})
        del trace[:-60]

    def output(reply, question=None):
        learner._save()
        return {'reply': reply, 'phase': state['phase'], 'question': question,
                'subject': state.get('subject'), 'topic': state.get('topic'),
                'decisions': trace[-5:], 'profile': state.get('profile', {}),
                'topic_progress': progress.get(state.get('subject'), {})}

    if message.casefold() in ('restart lesson', 'start over', 'reset teacher'):
        state.clear()
        state.update({'phase': 'intro', 'lesson_index': 0, 'attempts': 0})
        record('Coordinator Agent', 'Restart teacher session', 'Learner requested a fresh teaching sequence')
        message = ''

    if not selected_subject:
        return output('Please select a subject in the classroom before starting your lesson.')

    if state['phase'] == 'intro':
        state['phase'] = 'select_lesson'
        record('Coordinator Agent', 'Autonomously select first lesson', 'Begin with available local syllabus material without asking the student to choose a subject')

    if state['phase'] == 'profiling':
        if not message:
            return output('Tell me which subject you find difficult, or say “choose for me” and I will begin with an available syllabus lesson.')
        state['profile'] = {'learning_goal': message}
        record('Memory Agent', 'Save student learning goal', 'Personalise the teaching sequence')
        state['phase'] = 'select_lesson'

    country = getattr(user, 'country', 'Nigeria')
    level = getattr(user, 'class_level', 'SS3')
    stream = getattr(user, 'stream', None)
    if state['phase'] == 'select_lesson':
        subjects = sorted({c.subject for c in tutor.retriever.chunks if c.country == country and c.class_level == level and (not c.stream or c.stream == stream)})
        chosen = next((subject for subject in subjects if subject.casefold() == selected_subject.casefold()), None)
        if not chosen:
            return output('No local teaching material is available for '+selected_subject+' at your class level. Please choose another available subject.')
        lessons = list_lessons(country=country, class_level=level, stream=stream, subject=chosen)
        if not lessons:
            # Existing project ships starter curriculum chunks, not reviewed lesson JSON.
            # Use those honestly as starter material rather than leaving the classroom empty.
            chunks = [c for c in tutor.retriever.chunks if c.country == country and c.class_level == level and c.subject == chosen and (not c.stream or c.stream == stream)]
            lessons = [{'lesson_id': 'chunk_'+str(i), 'topic': c.topic} for i,c in enumerate(chunks)]
            state['starter_chunks'] = [{'topic': c.topic, 'text': c.text} for c in chunks]
        if not lessons:
            return output('No offline curriculum material is available for your class and subject. I will not invent a syllabus.')
        subject_progress = progress.setdefault(chosen, {})
        first_unfinished = next((i for i, item in enumerate(lessons) if subject_progress.get(item['lesson_id'], {}).get('status') != 'completed'), len(lessons))
        state.update({'subject': chosen, 'lesson_ids': [x['lesson_id'] for x in lessons], 'lesson_index': first_unfinished, 'phase': 'teach' if first_unfinished < len(lessons) else 'finished'})
        record('Curriculum Agent', 'Choose '+chosen, 'Matched student goal and available reviewed lessons')

    if state['phase'] == 'finished':
        return output('You have completed all locally available topics in '+selected_subject+'. Your progress is saved.')

    if state['phase'] == 'teach':
        ids = state['lesson_ids']
        idx = min(state['lesson_index'], len(ids)-1)
        if ids[idx].startswith('chunk_') and 'starter_chunks' in state:
            from types import SimpleNamespace
            chunk = state['starter_chunks'][idx]
            lesson = SimpleNamespace(topic=chunk['topic'], lesson_sections=[SimpleNamespace(title='Starter curriculum note', content=chunk['text'])], worked_examples=[], practice_questions=[SimpleNamespace(question='In your own words, explain one important idea from this lesson.', answer=chunk['text'])])
        else:
            lesson = load_lesson(ids[idx], country=country, class_level=level, stream=stream, subject=state['subject'])
        state['topic'] = lesson.topic
        topic_record = progress.setdefault(state['subject'], {}).setdefault(ids[idx], {'topic': lesson.topic, 'status': 'not_started', 'attempts': 0})
        topic_record['status'] = 'in_progress'
        topic_record['last_studied'] = now
        explanation = '\n\n'.join(sec.title + ': ' + sec.content for sec in lesson.lesson_sections)
        examples = '\n'.join(ex.title + ': ' + ex.problem + ' → ' + ex.solution for ex in lesson.worked_examples[:2])
        question = lesson.practice_questions[0] if lesson.practice_questions else None
        state['expected_answer'] = question.answer if question else None
        state['question'] = question.question if question else None
        state['attempts'] = 0
        state.pop('assessment_kind', None)
        state['phase'] = 'demonstrate' if question else 'next_lesson'
        learner.record_study(state['subject'], lesson.topic, 'teacher_led_lesson')
        record('Teaching Agent', 'Teach '+lesson.topic, 'Next reviewed lesson in locally available sequence')
        record('Assessment Agent', 'Ask comprehension question' if question else 'No reviewed question available', 'Check understanding without requiring Practice menu')
        reply = 'Today we are studying '+lesson.topic+'.\n\n'+explanation
        if examples: reply += '\n\nWorked example: '+examples
        if question:
            reply += '\n\nFirst, read this explanation. When you are ready, press Start / Resume Lesson again to see a worked demonstration. I will ask you a question only after the demonstration.'
        else:
            reply += '\n\nThis lesson has no reviewed practice question; it cannot be marked mastered without an assessment.'
        return output(reply)

    # A restart/resume click must not be treated as a wrong answer.
    # Learners can request clarification at any point in the assessment.
    confusion = re.search(r"\b(don.t understand|do not understand|didn.t understand|confused|lost|didn.t learn|do not get|don.t get|explain again|teach me again|too hard|help me understand)\b", message.casefold())
    if state['phase'] == 'question' and confusion:
        topic = state.get('topic', '')
        if 'indices' in topic.casefold() or 'logarithm' in topic.casefold():
            state['question'] = 'What is 3²? A) 5  B) 6  C) 9'
            state['expected_answer'] = '9'
            state['assessment_kind'] = 'indices_basic'
            explanation = ('That is okay. I will explain with smaller steps.\n\n'
                'An index (exponent) is the small raised number. It tells you how many times to multiply the base by itself.\n'
                'For example, 2³ means 2 × 2 × 2 = 8.\n'
                'Another example: 3² means 3 × 3 = 9. The answer is NOT 3 × 2.\n\n'
                'Now try just one short question: '+state['question'])
        else:
            explanation = ('Thanks for telling me. We will stay on this topic. '
                'Here is the main idea from the lesson note:\n'+str(state.get('expected_answer') or '')[:900]+
                '\n\nWhich part is confusing? You can ask about a particular step, or try: '+str(state.get('question') or ''))
        record('Teaching Agent', 'Reteach after learner confusion', 'Learner explicitly said they did not understand; do not count this as a failed assessment')
        return output(explanation, state.get('question'))

    if state['phase'] == 'demonstrate':
        # Deliberately separate teaching from assessment; a fresh learner is not
        # presented with a question in the same turn as the first explanation.
        topic = state.get('topic', '')
        if 'indices' in topic.casefold() or 'logarithm' in topic.casefold():
            # The starter Mathematics topic contains an indices chunk followed by a
            # logarithms chunk. Demonstrate the relevant chunk, not reading skills.
            note = str(state.get('expected_answer') or '').casefold()
            is_log = 'logarithm' in note or 'log base' in note or 'log_' in note
            if is_log:
                demonstration = (
                    'Worked demonstration — Logarithms:\n'
                    'Step 1: 10 × 10 = 100, so 10² = 100.\n'
                    'Step 2: A logarithm asks: what power of 10 gives 100?\n'
                    'Step 3: log₁₀(100) = 2, because 10² = 100.\n'
                    'Another example: 10³ = 1000, so log₁₀(1000) = 3.'
                )
                state['question'] = 'What is log₁₀(1000)? A) 2  B) 3  C) 10'
                state['expected_answer'] = '3'
                state['assessment_kind'] = 'logarithms_basic'
            else:
                demonstration = (
                    'Worked demonstration — Indices:\n'
                    'Step 1: 2³ means multiply three 2s: 2 × 2 × 2 = 8.\n'
                    'Step 2: 3² means multiply two 3s: 3 × 3 = 9.\n'
                    'The raised number counts factors, not repeated addition.'
                )
                state['question'] = 'What is 3²? A) 5  B) 6  C) 9'
                state['expected_answer'] = '9'
                state['assessment_kind'] = 'indices_basic'
        elif 'comprehension' in topic.casefold() or 'summary' in topic.casefold():
            demonstration = (
                'Worked demonstration (illustrative passage):\n'
                'Passage: “The school library opens early. Many pupils visit before lessons '
                'to read and borrow books. The librarian helps them find useful materials.”\n'
                'Step 1 — Main idea: the school library helps pupils learn.\n'
                'Step 2 — Supporting details: it opens early; pupils read and borrow books; '
                'the librarian helps them.\n'
                'Step 3 — Summary in our own words: “Pupils use the early-opening school '
                'library for reading and borrowing books with help from the librarian.”'
            )
            question = ('Read this short passage: “Amina plants vegetables behind her house. '
                        'She waters them each morning and shares the harvest with her neighbours.” '
                        'What is the main idea, and give one supporting detail?')
            expected = ('Main idea: Amina grows vegetables and shares her harvest. '
                        'Supporting detail: she waters them each morning (or plants them behind her house).')
            state['question'] = question
            state['expected_answer'] = expected
        else:
            demonstration = (
                'Guided demonstration using the lesson note:\n'
                '1. Identify the central idea in the explanation above.\n'
                '2. Find the detail in the note that supports it.\n'
                '3. Explain how the detail supports the central idea in your own words.\n'
                'This is a reading demonstration, not a subject-specific worked calculation. '
                'A verified worked example is not available for this starter topic yet.'
            )
        state['phase'] = 'question'
        record('Teaching Agent', 'Demonstrate '+topic, 'Show an example before the first assessment')
        return output(demonstration+'\n\nNow your turn: '+state['question'], state['question'])

    # Classify requests for teaching BEFORE assessment. A request for an
    # explanation is never evidence of mastery, even without a question mark.
    help_request = bool(re.search(
        r"\b(?:please\s+)?(?:explain|demonstrate|show|teach|walk me through|"
        r"give me (?:an? )?example|show me (?:an? )?example|"
        r"help me|can you explain|could you explain|how does|how do|why does|"
        r"what does|what is a logarithm|what are logarithms)\b",
        message.casefold()))
    if state['phase'] == 'question' and help_request:
        topic = str(state.get('topic') or '')
        note = str(state.get('expected_answer') or '').casefold()
        is_math = 'indices' in topic.casefold() or 'logarithm' in topic.casefold()
        asks_log = 'log' in message.casefold()
        is_log = asks_log or (is_math and ('logarithm' in note or 'log base' in note or 'log_' in note))
        if is_math:
            if is_log:
                reply = ('Let us work through logarithms step by step.\n\n'
                         '1. 10 × 10 = 100, so 10² = 100.\n'
                         '2. A logarithm asks which power of 10 gives 100.\n'
                         '3. Therefore log₁₀(100) = 2.\n'
                         '4. Similarly, 10³ = 1000, so log₁₀(1000) = 3.\n\n'
                         'Try this: What is log₁₀(1000)? A) 2  B) 3  C) 10')
                state.update(question='What is log₁₀(1000)? A) 2  B) 3  C) 10',
                             expected_answer='3', assessment_kind='logarithms_basic')
            else:
                reply = ('Let us work through indices step by step.\n\n'
                         '1. 2³ means 2 × 2 × 2 = 8.\n'
                         '2. 3² means 3 × 3 = 9, not 3 × 2.\n\n'
                         'Try this: What is 3²? A) 5  B) 6  C) 9')
                state.update(question='What is 3²? A) 5  B) 6  C) 9',
                             expected_answer='9', assessment_kind='indices_basic')
        else:
            reply = ('I will explain that again. Here is the lesson reference:\n'
                     + str(state.get('expected_answer') or '')[:900]
                     + '\n\nWhen you are ready, answer: ' + str(state.get('question') or ''))
        record('Teaching Agent', 'Explain on request',
               'Learner asked for teaching, not assessment; do not update mastery or attempts')
        return output(reply, state.get('question'))

    if state['phase'] == 'question':
        if not message:
            return output('Try this question: '+state['question'], state['question'])
        if message.casefold() in ('repeat', 'repeat question', 'hint', 'help'):
            record('Teaching Agent', 'Offer guided revision', 'Learner requested help before answering')
            return output('Hint: revisit the key ideas from the lesson. You can ask me to explain a specific step.\n\nQuestion: '+state['question'], state['question'])
        if message.startswith('Please explain this uploaded learning material'):
            record('Multimodal Agent', 'Interpret uploaded classroom material', 'Student provided a document or image for contextual teaching')
            try:
                response = tutor.answer(message[:1800], level, state['subject'], learner.get_mastery(state.get('topic','')), country=country, stream=stream)
                explanation = str(response.get('answer') or response.get('response') or response)
            except Exception:
                explanation = 'I received the extracted text. Key material: '+message.split(': ',1)[-1][:1100]
            return output(explanation+'\n\nReturning to our lesson, answer: '+state['question'], state['question'])
        if message.endswith('?') and len(message.split()) > 3:
            record('Teaching Agent', 'Answer learner clarification', 'Learner asked a question during assessment')
            try:
                response = tutor.answer(message, level, state['subject'], learner.get_mastery(state.get('topic','')), country=country, stream=stream)
                return output(str(response.get('answer') or response.get('response') or response)+'\n\nWhen ready, answer: '+state['question'], state['question'])
            except Exception:
                return output('I could not generate an additional explanation. Here is the lesson reference: '+str(state.get('expected_answer',''))+'\n\nQuestion: '+state['question'], state['question'])
        expected = state['expected_answer']
        if state.get('assessment_kind') in ('indices_basic', 'logarithms_basic'):
            # Deterministic grading for a deliberately simple, unambiguous check.
            normalized = message.strip().casefold()
            if state.get('assessment_kind') == 'logarithms_basic':
                correct = bool(re.fullmatch(r'(?:b[\).]?\s*)?(?:3|three)(?:\s*[.!])?', normalized)) or normalized in ('b', 'option b', 'answer b', 'b) 3', 'b. 3')
            else:
                correct = bool(re.fullmatch(r'(?:c[\).]?\s*)?(?:9|nine)(?:\s*[.!])?', normalized)) or normalized in ('c', 'option c', 'answer c', 'c) 9', 'c. 9')
            uncertain = False
        else:
            correct = None
        normalize = lambda t: re.sub(r'[^a-z0-9]+', '', t.casefold())
        if correct is None:
            correct = normalize(message) == normalize(expected)
        uncertain = False
        if not correct and state.get('assessment_kind') not in ('indices_basic', 'logarithms_basic'):
            # Model grading is used only with the known reference answer; if unavailable,
            # a non-exact response is marked uncertain, not incorrectly graded.
            try:
                import json
                raw = llm.generate('Grade this school answer against the provided expected answer. Reply ONLY JSON {"correct":true or false,"feedback":"brief reason"}.\nQuestion: '+state['question']+'\nExpected: '+expected+'\nStudent: '+message, max_tokens=140)
                match = re.search(r'\{.*?\}', raw, re.S)
                if match:
                    result = json.loads(match.group())
                    if isinstance(result.get('correct'), bool):
                        correct = result['correct']
                    else:
                        uncertain = True
                else:
                    uncertain = True
            except (ConnectionError, ValueError, TypeError, OSError, RuntimeError):
                uncertain = True
        if uncertain:
            record('Assessment Agent', 'Request teacher review', 'Local model unavailable; cannot reliably grade a free-text answer')
            return output('I cannot reliably grade that free-text answer while the local AI model is unavailable. Here is the lesson reference: '+expected+'\n\nPlease try again when Ollama is running.', state['question'])
        state['attempts'] += 1
        topic_record = progress.setdefault(state['subject'], {}).setdefault(state['lesson_ids'][state['lesson_index']], {'topic': state['topic']})
        topic_record['attempts'] = topic_record.get('attempts', 0) + 1
        topic_record['last_studied'] = now
        if correct:
            mastery = learner.update_subject_mastery(state['subject'], state['topic'], True)
            record('Progress Agent', 'Update mastery', 'Student answered the teacher question correctly')
            topic_record['status'] = 'completed'
            topic_record['completed_at'] = now
            state['lesson_index'] += 1
            state['phase'] = 'next_lesson'
            if state['lesson_index'] < len(state['lesson_ids']):
                next_turn = teacher_step(learner, user, 'next', list_lessons, load_lesson, tutor, llm, selected_subject=selected_subject)
                next_turn['reply'] = 'Well done! Your mastery estimate is '+str(round(mastery*100))+'%. Let us continue.\n\n' + next_turn['reply']
                return next_turn
            return output('Well done! Your mastery estimate is '+str(round(mastery*100))+'%. You have completed the available lessons in this subject. Your progress is saved.')
        topic_record['status'] = 'in_progress'
        mastery = learner.update_subject_mastery(state['subject'], state['topic'], False)
        record('Assessment Agent', 'Detect knowledge gap', 'Answer did not match the expected response')
        record('Planning Agent', 'Repeat with feedback', 'Keep student on the topic instead of advancing')
        if state.get('assessment_kind') == 'logarithms_basic':
            return output('Not quite. Since 10³ = 1000, log₁₀(1000) = 3. Try again: '+state['question'], state['question'])
        if state.get('assessment_kind') == 'indices_basic':
            return output('Not quite. Remember, 3² means 3 × 3, not 3 × 2. Try again: '+state['question'], state['question'])
        return output('Let us review that together. The expected answer is: '+expected+'\n\nTry again: '+state['question'], state['question'])

    if state['phase'] == 'next_lesson':
        if message and message.lower() not in ('next','continue','continue lesson','yes','go on'):
            record('Coordinator Agent', 'Respond to learner interruption', 'Student asked a question before advancing')
            try:
                response = tutor.answer(message, level, state['subject'], learner.get_mastery(state.get('topic','')), country=country, stream=stream)
                return output(str(response.get('answer') or response.get('response') or response))
            except (ConnectionError, ValueError):
                return output('I cannot generate that explanation right now. Say “next” when you are ready to continue.')
        if state['lesson_index'] >= len(state['lesson_ids']):
            state['phase'] = 'finished'
            record('Planning Agent', 'Finish available lesson sequence', 'No additional reviewed lessons in this subject')
            return output('You have completed the locally available reviewed lessons for '+state['subject']+'. Your progress has been saved. More verified syllabus lessons are needed before I can teach further.')
        state['phase'] = 'teach'
        return teacher_step(learner, user, 'next', list_lessons, load_lesson, tutor, llm, selected_subject=selected_subject)

    return output('Your available lesson sequence is complete. Your progress has been saved.')
