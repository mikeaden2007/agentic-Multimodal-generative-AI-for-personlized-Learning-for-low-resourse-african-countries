"""Filesystem-only loader for reviewed offline lessons."""

import json
from pathlib import Path
from typing import Optional

from pydantic import ValidationError

from app.lesson_schema import Lesson


LESSON_DIRECTORY = Path(__file__).resolve().parent / "data" / "lessons"


class LessonUnavailableError(Exception):
    """No reviewed, profile-matching local lesson is available."""


def _lesson_file(root: Path, lesson_id: str) -> Path:
    if not lesson_id or not all(char.isalnum() or char in "_-" for char in lesson_id):
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.")
    root = root.resolve()
    candidate = (root / f"{lesson_id}.json").resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.") from exc
    return candidate


def load_lesson(
    lesson_id: str,
    *,
    country: str,
    class_level: str,
    stream: Optional[str] = None,
    subject: Optional[str] = None,
    lesson_directory: Optional[Path] = None,
) -> Lesson:
    """Load and validate one reviewed lesson matching the authenticated profile."""
    root = Path(lesson_directory or LESSON_DIRECTORY).resolve()
    path = _lesson_file(root, lesson_id)
    try:
        path.relative_to(root)
        raw = json.loads(path.read_text(encoding="utf-8"))
        lesson = Lesson.model_validate(raw)
    except (OSError, UnicodeError, json.JSONDecodeError, ValidationError, ValueError) as exc:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.") from exc

    if lesson.lesson_id != lesson_id or lesson.review_status != "reviewed" or not lesson.source_references:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.")
    if lesson.country != country or lesson.class_level != class_level:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.")
    if lesson.stream is not None and lesson.stream != stream:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.")
    if subject is not None and lesson.subject != subject:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.")

    for illustration in lesson.illustrations:
        image_path = (root / illustration.path).resolve()
        try:
            image_path.relative_to(root)
        except ValueError as exc:
            raise LessonUnavailableError("Verified lesson is unavailable for this learner.") from exc
        if not image_path.is_file():
            raise LessonUnavailableError("Verified lesson is unavailable for this learner.")

    return lesson

def list_lessons(*, country: str, class_level: str, subject: str, stream: Optional[str] = None, lesson_directory: Optional[Path] = None) -> list[dict]:
    """Discover only accessible reviewed lessons; never write learner data."""
    root = Path(lesson_directory or LESSON_DIRECTORY).resolve()
    if not root.is_dir():
        return []
    results = []
    for path in sorted(root.glob("*.json")):
        try:
            # load_lesson checks file containment, schema, review status and profile.
            lesson = load_lesson(path.stem, country=country, class_level=class_level,
                                 subject=subject, stream=stream, lesson_directory=root)
        except LessonUnavailableError:
            continue
        results.append({"lesson_id": lesson.lesson_id, "topic": lesson.topic, "subject": lesson.subject})
    return results
