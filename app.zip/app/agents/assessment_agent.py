"""
Assessment agent.

Generates a short practice question grounded in retrieved curriculum
content, and scores the learner's free-text answer against that same
content. Also grounded via RAG for the same reason as the tutor agent.
"""

import json
import re

from app.rag.retriever import CurriculumRetriever
from app.llm_client import LLMClient
from typing import Optional


class AssessmentAgent:
    def __init__(self, retriever: CurriculumRetriever, llm: LLMClient):
        self.retriever = retriever
        self.llm = llm

    def generate_question(self, topic: str, class_level: str, subject: str,
                           country: Optional[str] = None, stream: Optional[str] = None) -> dict:
        chunks = self.retriever.retrieve(
            query=topic, class_level=class_level, subject=subject,
            country=country, stream=stream, top_k=2,
        )
        if not chunks:
            return {"question": None, "sources": []}

        context = "\n\n".join(f"- {c.text}" for c in chunks)
        prompt = f"""Based ONLY on the following curriculum material, write ONE short
practice question (not multiple choice) for a school student to test their
understanding. Reply with ONLY the question text, nothing else.

Curriculum material:
{context}

Question:"""
        question = self.llm.generate(prompt, max_tokens=100)
        return {"question": question.strip(), "sources": [c.id for c in chunks]}

    def score_answer(self, question: str, student_answer: str, source_chunk_ids: list[str],
                      retriever: CurriculumRetriever) -> dict:
        context_chunks = [c for c in retriever.chunks if c.id in source_chunk_ids]
        context = "\n\n".join(f"- {c.text}" for c in context_chunks)

        prompt = f"""You are grading a school student's answer using ONLY the
reference material below. Be encouraging but honest.

Reference material:
{context}

Question: {question}
Student's answer: {student_answer}

Reply in exactly this JSON format, with no other text:
{{"correct": true or false, "feedback": "one or two encouraging sentences explaining why"}}
"""
        raw = self.llm.generate(prompt, max_tokens=150)

        match = re.search(r'\{.*\}', raw, re.DOTALL)
        if match:
            try:
                parsed = json.loads(match.group(0))
                return {
                    "correct": bool(parsed.get("correct", False)),
                    "feedback": parsed.get("feedback", ""),
                }
            except json.JSONDecodeError:
                pass

        # Fallback if the model didn't return valid JSON -- fail safe,
        # don't silently mark wrong answers as correct.
        return {"correct": False, "feedback": raw.strip() or "Could not evaluate the answer automatically."}
