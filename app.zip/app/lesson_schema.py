"""Validated schema for reviewed, locally stored teaching lessons."""

from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


class LessonSection(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=1, max_length=200)
    content: str = Field(min_length=1)


class WorkedExample(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=1, max_length=200)
    problem: str = Field(min_length=1)
    solution: str = Field(min_length=1)


class LocalIllustration(BaseModel):
    model_config = ConfigDict(extra="forbid")

    path: str = Field(min_length=1, max_length=500)
    alt_text: str = Field(min_length=1, max_length=500)
    caption: Optional[str] = Field(default=None, max_length=500)

    @field_validator("path")
    @classmethod
    def validate_relative_path(cls, value: str) -> str:
        normalized = value.replace("\\", "/")
        if normalized.startswith("/") or ":" in normalized:
            raise ValueError("illustration path must be relative to the lesson directory")
        if any(part in {"", ".", ".."} for part in normalized.split("/")):
            raise ValueError("illustration path contains an unsafe path component")
        return normalized


class PracticeQuestion(BaseModel):
    model_config = ConfigDict(extra="forbid")

    question: str = Field(min_length=1)
    answer: str = Field(min_length=1)


class SourceReference(BaseModel):
    model_config = ConfigDict(extra="forbid")

    source_id: str = Field(min_length=1, max_length=150)
    title: str = Field(min_length=1, max_length=500)
    publisher: str = Field(min_length=1, max_length=300)
    locator: str = Field(min_length=1, max_length=300)


class Lesson(BaseModel):
    model_config = ConfigDict(extra="forbid")

    lesson_id: str = Field(pattern=r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$")
    country: str = Field(min_length=1, max_length=100)
    class_level: str = Field(min_length=1, max_length=100)
    subject: str = Field(min_length=1, max_length=200)
    stream: Optional[str] = Field(default=None, max_length=100)
    topic: str = Field(min_length=1, max_length=250)
    learning_objectives: list[str] = Field(min_length=1)
    lesson_sections: list[LessonSection] = Field(min_length=1)
    worked_examples: list[WorkedExample] = Field(default_factory=list)
    illustrations: list[LocalIllustration] = Field(default_factory=list)
    summary: str = Field(min_length=1)
    practice_questions: list[PracticeQuestion] = Field(default_factory=list)
    source_references: list[SourceReference] = Field(min_length=1)
    review_status: Literal["draft", "reviewed"]
    schema_version: Literal[1]

    @field_validator("learning_objectives")
    @classmethod
    def require_non_empty_items(cls, values: list[str]) -> list[str]:
        if any(not value.strip() for value in values):
            raise ValueError("entries must be non-empty strings")
        return values