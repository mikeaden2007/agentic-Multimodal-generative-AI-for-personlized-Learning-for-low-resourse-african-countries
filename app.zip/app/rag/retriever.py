"""
Curriculum retriever for the tutoring agent.

Design choice: this uses TF-IDF (scikit-learn) rather than a downloaded
neural embedding model. This is deliberate, not a shortcut -- it means
retrieval works with zero external downloads and zero GPU, consistent
with the offline-first, low-resource-device design principle from the
reference architecture. For a production deployment with a larger
curriculum corpus, swap this for sqlite-vec or Chroma with a small
on-device embedding model (see Section 4a of the reference architecture),
but TF-IDF is a legitimate, fully local starting point for a
demonstrable prototype.
"""

import json
import glob
import os
from dataclasses import dataclass
from typing import Optional

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class Chunk:
    id: str
    text: str
    country: str
    class_level: str
    subject: str
    topic: str
    stream: Optional[str] = None  # "Science" | "Commercial" | "Arts" | None (compulsory/no stream)


class CurriculumRetriever:
    def __init__(self, data_dir: str):
        self.data_dir = data_dir
        self.chunks: list[Chunk] = []
        self._vectorizer: Optional[TfidfVectorizer] = None
        self._matrix = None
        self._load()

    def _load(self):
        """Load every curriculum JSON file in data_dir into flat chunks."""
        self.chunks = []
        for path in glob.glob(os.path.join(self.data_dir, "*.json")):
            with open(path, "r", encoding="utf-8") as f:
                doc = json.load(f)
            for c in doc["chunks"]:
                self.chunks.append(
                    Chunk(
                        id=c["id"],
                        text=c["text"],
                        country=doc.get("country", "Nigeria"),
                        class_level=doc["class_level"],
                        subject=doc["subject"],
                        topic=doc["topic"],
                        stream=doc.get("stream"),
                    )
                )
        if not self.chunks:
            raise RuntimeError(f"No curriculum chunks found in {self.data_dir}")

        texts = [c.text for c in self.chunks]
        self._vectorizer = TfidfVectorizer(stop_words="english")
        self._matrix = self._vectorizer.fit_transform(texts)

    def available_countries(self) -> list[str]:
        return sorted(set(c.country for c in self.chunks))

    def available_classes(self, country: Optional[str] = None) -> list[str]:
        classes = (
            c.class_level for c in self.chunks
            if country is None or c.country == country
        )
        return sorted(set(classes))

    def available_streams(self, country: str, class_level: str) -> list[str]:
        """Streams are only meaningful for senior secondary classes (SS1-3).
        Returns [] for classes with no streaming (e.g. junior secondary)."""
        streams = (
            c.stream for c in self.chunks
            if c.country == country and c.class_level == class_level and c.stream
        )
        return sorted(set(streams))

    def available_subjects(self, class_level: Optional[str] = None,
                            country: Optional[str] = None,
                            stream: Optional[str] = None) -> list[str]:
        subjects = (
            c.subject for c in self.chunks
            if (class_level is None or c.class_level == class_level)
            and (country is None or c.country == country)
            # a subject is available to a stream if it's tagged for that
            # stream OR has no stream restriction (compulsory subject)
            and (stream is None or c.stream is None or c.stream == stream)
        )
        return sorted(set(subjects))

    def available_topics(self, class_level: str, subject: str,
                          country: Optional[str] = None,
                          stream: Optional[str] = None) -> list[str]:
        """
        Distinct topics within a subject, in the order they first appear
        in the curriculum data (stable, deterministic order -- this is
        what the planner agent enumerates over to build a session plan).
        """
        seen = []
        for c in self.chunks:
            if (c.class_level == class_level and c.subject == subject
                    and (country is None or c.country == country)
                    and (stream is None or c.stream is None or c.stream == stream)
                    and c.topic not in seen):
                seen.append(c.topic)
        return seen

    def retrieve(
        self,
        query: str,
        class_level: Optional[str] = None,
        subject: Optional[str] = None,
        country: Optional[str] = None,
        stream: Optional[str] = None,
        top_k: int = 3,
    ) -> list[Chunk]:
        """
        Retrieve the top_k most relevant curriculum chunks for a query,
        optionally filtered by country, class level, subject, and stream.
        This is the RAG grounding step (RQ4): the tutor agent is only
        allowed to answer from chunks returned here, not from open-ended
        generation, to bound hallucination risk.
        """
        candidate_idx = [
            i for i, c in enumerate(self.chunks)
            if (country is None or c.country == country)
            and (class_level is None or c.class_level == class_level)
            and (subject is None or c.subject == subject)
            and (stream is None or c.stream is None or c.stream == stream)
        ]
        if not candidate_idx:
            return []

        query_vec = self._vectorizer.transform([query])
        sims = cosine_similarity(query_vec, self._matrix[candidate_idx]).flatten()

        ranked = sorted(zip(candidate_idx, sims), key=lambda x: x[1], reverse=True)
        top = [idx for idx, score in ranked[:top_k] if score > 0]
        return [self.chunks[i] for i in top]
