"""
Tutor agent.

Answers a learner's question by first retrieving grounded curriculum
chunks (RAG) and then asking the LLM to explain using ONLY that
retrieved content. This is the architectural answer to RQ4 (factual
reliability): the LLM is not asked to answer from its own general
knowledge, which bounds hallucination risk in a domain where errors
compound.

If no relevant curriculum content is found, the agent says so honestly
rather than falling back to open-ended generation -- this is a
deliberate design choice, not a missing feature.
"""

from app.rag.retriever import CurriculumRetriever, Chunk
from app.llm_client import LLMClient
from app.agents.calculator_tool import solve_math
from typing import Optional


class TutorAgent:
    def __init__(self, retriever: CurriculumRetriever, llm: LLMClient):
        self.retriever = retriever
        self.llm = llm

    def _build_prompt(self, question: str, chunks: list[Chunk], mastery: float) -> str:
        context = "\n\n".join(f"- {c.text}" for c in chunks)

        if mastery < 0.4:
            style = "Explain this very simply, as if to a beginner, using short sentences and a concrete example."
        elif mastery < 0.7:
            style = "Give a clear, moderately detailed explanation, building on basic understanding."
        else:
            style = "Give a concise explanation, since the learner already shows strong understanding of this topic."

        return f"""You are a patient, encouraging tutor for a school student in Nigeria.

Use ONLY the following curriculum material to answer the student's question.
Do not add facts that are not supported by this material. If the material
does not fully answer the question, say what you can from it and note that
the rest is outside today's lesson material.

Curriculum material:
{context}

Student's question: {question}

Instruction: {style}

Response format (plain text with lightweight Markdown headings):
- Start directly with a brief definition or direct answer. Do not greet the student.
- Use short sections headed **Meaning**, **Key points**, and **Example** when
  those sections are supported by the curriculum excerpts.
- Use numbered steps for processes or worked examples; use short bullets
  for lists. Keep paragraphs brief and avoid repetitive analogies.
- Finish with **Summary** (one or two sentences).
- Do not invent examples, equations, diagrams, or facts absent from the
  provided material. Omit a section if the excerpts do not support it.
- If the supplied material is insufficient, explicitly say so.
- Be respectful and age-appropriate; do not address the learner as 'child'.
- Do not include HTML or pretend to cite sources not provided.

Your explanation:"""

    def _build_computation_intro_prompt(self, question: str, verified_result: str) -> str:
        return f"""A student asked: "{question}"
The verified answer, already worked out step by step, is: {verified_result}

Write ONE short, encouraging sentence (max 20 words) to introduce the
worked solution below. Do not state a different answer. Do not add any
extra working of your own -- the steps are shown separately."""

    def answer(self, question: str, class_level: str, subject: str, mastery: float,
               country: Optional[str] = None, stream: Optional[str] = None) -> dict:
        # Computation-grounding: if this is a genuine arithmetic/algebra
        # question, get a REAL verified answer AND real step-by-step
        # working first (sympy, not the LLM narrating), the way a
        # teacher would show working on a board -- not a paragraph of
        # prose describing it. The LLM's only role here is a short,
        # optional framing sentence; the steps themselves never depend
        # on it, so a verified worked solution is still returned in
        # full even if the LLM backend is unreachable.
        calc = solve_math(question)
        if calc.is_computable:
            try:
                intro = self.llm.generate(
                    self._build_computation_intro_prompt(question, calc.result), max_tokens=60
                ).strip()
            except ConnectionError:
                intro = "Here's the worked solution:"
            return {
                "answer": intro,
                "steps": calc.steps,
                "grounded": True,
                "grounding_method": "computation",
                "verified_result": calc.result,
                "sources": [],
            }

        chunks = self.retriever.retrieve(
            query=question, class_level=class_level, subject=subject,
            country=country, stream=stream, top_k=3,
        )

        if not chunks:
            return {
                "answer": (
                    "I don't have curriculum material covering that topic yet for "
                    f"{class_level} {subject}. Try asking about a topic in the "
                    "current lesson, or ask your teacher to add this topic to the "
                    "curriculum library."
                ),
                "steps": [],
                "grounded": False,
                "grounding_method": "none",
                "sources": [],
            }

        prompt = self._build_prompt(question, chunks, mastery)
        try:
            explanation = self.llm.generate(prompt, max_tokens=650)
        except ConnectionError:
            explanation = ""
        if not explanation.strip():
            # Display genuine retrieved material rather than an empty answer.
            explanation = ("Meaning\n" + chunks[0].text +
                           "\n\nKey points\n" +
                           "\n".join("- " + c.text for c in chunks[1:]) +
                           "\n\nSummary\nThese are the available lesson notes for this topic. "
                           "A fuller AI explanation is temporarily unavailable.")

        return {
            "answer": explanation,
            "steps": [],
            "grounded": True,
            "grounding_method": "retrieval",
            "sources": [c.id for c in chunks],
        }
