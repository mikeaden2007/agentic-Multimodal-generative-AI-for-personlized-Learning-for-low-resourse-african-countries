"""
Authentication for student accounts.

Design choices, stated honestly:
- Passwords are hashed with PBKDF2-HMAC-SHA256 (100,000 iterations) with a
  random per-user salt, using only Python's standard library (hashlib +
  secrets) -- no extra dependency, no plaintext storage. This is a
  legitimate, correct hashing approach.
- User records are stored in SQLite (also standard library, zero setup,
  a single local file) -- appropriate for a prototype/demo, consistent
  with the project's zero-external-dependency design principle.
- Session tokens are random strings held in an IN-MEMORY dictionary,
  not JWTs, and are lost if the server restarts. This is a genuine
  limitation for anything beyond a local demo: there is no token
  expiry, no HTTPS enforcement, and no CSRF protection. A real
  deployment needs a proper auth library (e.g. fastapi-users) and
  HTTPS termination -- this is flagged here, not hidden.
"""

import sqlite3
import hashlib
import secrets
import os
from dataclasses import dataclass
from typing import Optional


@dataclass
class User:
    id: str
    name: str
    email: str
    country: str
    class_level: str
    academic_goal: str
    stream: Optional[str] = None
    role: str = "student"


class AuthError(Exception):
    pass


class AuthStore:
    def __init__(self, db_path: str):
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path
        self._init_db()
        self._sessions: dict[str, str] = {}  # token -> user_id, in-memory only

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                password_salt TEXT NOT NULL,
                country TEXT NOT NULL,
                class_level TEXT NOT NULL,
                stream TEXT,
                academic_goal TEXT NOT NULL,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        columns = {r[1] for r in conn.execute("PRAGMA table_info(users)")}
        if "role" not in columns:
            conn.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'student'")
        conn.execute("""CREATE TABLE IF NOT EXISTS parent_links (
            parent_id TEXT NOT NULL, student_id TEXT NOT NULL,
            PRIMARY KEY(parent_id, student_id),
            FOREIGN KEY(parent_id) REFERENCES users(id),
            FOREIGN KEY(student_id) REFERENCES users(id))""")
        conn.commit()
        conn.close()

    @staticmethod
    def _hash_password(password: str, salt: bytes) -> str:
        return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 100_000).hex()

    def sign_up(self, name: str, email: str, password: str, country: str,
                class_level: str, academic_goal: str, stream: Optional[str] = None) -> tuple[str, User]:
        email = email.strip().lower()
        if len(password) < 6:
            raise AuthError("Password must be at least 6 characters.")

        conn = sqlite3.connect(self.db_path)
        existing = conn.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
        if existing:
            conn.close()
            raise AuthError("An account with this email already exists.")

        user_id = secrets.token_hex(8)
        salt = secrets.token_bytes(16)
        password_hash = self._hash_password(password, salt)

        conn.execute(
            "INSERT INTO users (id, name, email, password_hash, password_salt, country, class_level, stream, academic_goal) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (user_id, name, email, password_hash, salt.hex(), country, class_level, stream, academic_goal),
        )
        conn.commit()
        conn.close()

        token = self._create_session(user_id)
        user = User(id=user_id, name=name, email=email, country=country,
                     class_level=class_level, academic_goal=academic_goal, stream=stream, role="student")
        return token, user

    def log_in(self, email: str, password: str) -> tuple[str, User]:
        email = email.strip().lower()
        conn = sqlite3.connect(self.db_path)
        row = conn.execute(
            "SELECT id, name, email, password_hash, password_salt, country, class_level, stream, academic_goal, role "
            "FROM users WHERE email = ?", (email,)
        ).fetchone()
        conn.close()

        if not row:
            raise AuthError("No account found with this email.")

        user_id, name, email, stored_hash, salt_hex, country, class_level, stream, academic_goal, role = row
        salt = bytes.fromhex(salt_hex)
        if self._hash_password(password, salt) != stored_hash:
            raise AuthError("Incorrect password.")

        token = self._create_session(user_id)
        user = User(id=user_id, name=name, email=email, country=country,
                     class_level=class_level, academic_goal=academic_goal, stream=stream, role=role)
        return token, user

    def _create_session(self, user_id: str) -> str:
        token = secrets.token_hex(24)
        self._sessions[token] = user_id
        return token

    def get_user_from_token(self, token: str) -> Optional[User]:
        user_id = self._sessions.get(token)
        if not user_id:
            return None
        conn = sqlite3.connect(self.db_path)
        row = conn.execute(
            "SELECT id, name, email, country, class_level, stream, academic_goal, role FROM users WHERE id = ?",
            (user_id,)
        ).fetchone()
        conn.close()
        if not row:
            return None
        return User(id=row[0], name=row[1], email=row[2], country=row[3],
                     class_level=row[4], stream=row[5], academic_goal=row[6], role=row[7])

    def list_users(self, country: Optional[str] = None, class_level: Optional[str] = None,
                    stream: Optional[str] = None) -> list[User]:
        """
        List students matching the given filters. This is what powers the
        teacher-facing class overview: a teacher picks a country/class/
        (optionally) stream and sees every registered student in that class.

        Honest limitation: there is no teacher role or teacher-specific
        authentication in this prototype -- any visitor to the teacher
        view can see any class's data by choosing the filters. A real
        deployment needs a proper teacher/admin role gate before this
        endpoint is exposed beyond a local demo.
        """
        conn = sqlite3.connect(self.db_path)
        query = "SELECT id, name, email, country, class_level, stream, academic_goal, role FROM users WHERE role = 'student'"
        params = []
        if country:
            query += " AND country = ?"
            params.append(country)
        if class_level:
            query += " AND class_level = ?"
            params.append(class_level)
        if stream:
            query += " AND stream = ?"
            params.append(stream)
        rows = conn.execute(query, params).fetchall()
        conn.close()
        return [User(id=r[0], name=r[1], email=r[2], country=r[3],
                      class_level=r[4], stream=r[5], academic_goal=r[6], role=r[7]) for r in rows]

    def linked_students(self, parent_id: str) -> list[User]:
        conn = sqlite3.connect(self.db_path)
        rows = conn.execute("""SELECT u.id, u.name, u.email, u.country, u.class_level,
            u.stream, u.academic_goal, u.role FROM users u
            JOIN parent_links p ON p.student_id = u.id
            WHERE p.parent_id = ? AND u.role = 'student'""", (parent_id,)).fetchall()
        conn.close()
        return [User(id=r[0], name=r[1], email=r[2], country=r[3],
                     class_level=r[4], stream=r[5], academic_goal=r[6], role=r[7]) for r in rows]
