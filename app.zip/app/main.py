"""
FastAPI backend for the agentic personalised-learning prototype.

Auth endpoints:
  POST /auth/signup   -> register a student, returns {token, user}
  POST /auth/login    -> log in, returns {token, user}
  GET  /auth/me        -> get current user from a token (Authorization: Bearer <token>)

Curriculum discovery (geography/stream aware):
  GET  /countries                                  -> list countries with content
  GET  /classes?country=...                        -> list class levels for a country
  GET  /streams?country=...&class_level=...        -> list streams (Science/Commercial/Arts),
                                                       empty list if the class has no streaming
  GET  /subjects?country=...&class_level=...&stream=... -> subjects available

Core loop (unchanged in spirit, now geography/stream aware):
  POST /ask
  POST /practice/generate
  POST /practice/submit
  GET  /learner/{learner_id}/summary

Run with:  uvicorn app.main:app --reload --port 8000
Requires Ollama running locally (see app/llm_client.py).
"""

import os
import json
import re
import uuid
from threading import Lock
from fastapi import FastAPI, HTTPException, Request, Header, UploadFile, File, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException
from pydantic import BaseModel
from typing import Literal, Optional

from app.rag.retriever import CurriculumRetriever
from app.llm_client import LLMClient
from app.learner_model import LearnerModel
from app.agents.learning_coordinator import decide_after_assessment, student_action
from app.agents.tutor_agent import TutorAgent
from app.agents.assessment_agent import AssessmentAgent
from app.agents.planner_agent import PlannerAgent
from app.auth import AuthStore, AuthError
from app.teacher_overview import build_class_overview
from app.ocr_service import MAX_UPLOAD_BYTES, extract_text_from_upload, OCRUnavailableError, tesseract_status
from app.nerdc_catalogue import build_nerdc_subject_response
from app.lesson_library import LessonUnavailableError, load_lesson, list_lessons

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CURRICULUM_DIR = os.path.join(BASE_DIR, "app", "data", "curriculum")
LEARNERS_DIR = os.path.join(BASE_DIR, "app", "data", "learners")
AUTH_DB_PATH = os.path.join(BASE_DIR, "app", "data", "users.db")

APP_VERSION = "2026.09-board"

app = FastAPI(title="Agentic Personalised Learning Prototype", version=APP_VERSION)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(ConnectionError)
async def ollama_connection_error_handler(request: Request, exc: ConnectionError):
    return JSONResponse(status_code=503, content={"error": "llm_unreachable", "message": str(exc)})


@app.exception_handler(AuthError)
async def auth_error_handler(request: Request, exc: AuthError):
    return JSONResponse(status_code=401, content={"error": "auth_error", "message": str(exc)})


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    # FastAPI's default is {"detail": ...}, but the front end reads
    # "message" -- so the real reason was being replaced by a generic
    # fallback. Return both keys so nothing is lost.
    return JSONResponse(status_code=exc.status_code,
                        content={"error": "http_error", "message": str(exc.detail), "detail": exc.detail})


@app.exception_handler(OCRUnavailableError)
async def ocr_unavailable_handler(request: Request, exc: OCRUnavailableError):
    return JSONResponse(status_code=503, content={"error": "ocr_unavailable", "message": str(exc)})


retriever = CurriculumRetriever(CURRICULUM_DIR)
llm = LLMClient()
tutor = TutorAgent(retriever, llm)
assessor = AssessmentAgent(retriever, llm)
planner = PlannerAgent(retriever, llm)
auth_store = AuthStore(AUTH_DB_PATH)


def get_learner(learner_id: str) -> LearnerModel:
    return LearnerModel(learner_id, LEARNERS_DIR)


def require_user(authorization: Optional[str] = Header(None)):
    """Extracts and validates a Bearer token, raising 401 if invalid/missing."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or malformed Authorization header.")
    token = authorization.removeprefix("Bearer ").strip()
    user = auth_store.get_user_from_token(token)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired session token.")
    return user


def require_role(role: str):
    def check(user=Depends(require_user)):
        if user.role != role:
            raise HTTPException(status_code=403, detail=f"{role.title()} account required.")
        return user
    return check


def require_learner_access(learner_id: str, user):
    if user.role != "student" or user.id != learner_id:
        raise HTTPException(status_code=403, detail="You cannot access another learner's record.")


# ---------- Request models ----------

class SignupRequest(BaseModel):
    name: str
    email: str
    password: str
    country: Literal["Nigeria", "Ghana"]
    class_level: str
    stream: Optional[str] = None
    academic_goal: str


class LoginRequest(BaseModel):
    email: str
    password: str


class AskRequest(BaseModel):
    learner_id: str
    class_level: str
    subject: str
    country: str
    stream: Optional[str] = None
    question: str


class PracticeGenerateRequest(BaseModel):
    learner_id: str
    class_level: str
    subject: str
    country: str
    stream: Optional[str] = None
    topic: str


class ObjectiveSubmitRequest(BaseModel):
    learner_id: str
    question_id: str
    answer: str


class PracticeSubmitRequest(BaseModel):
    learner_id: str
    topic: str
    question: str
    student_answer: str
    source_chunk_ids: list[str]
    subject: Optional[str] = None


class SessionPlanRequest(BaseModel):
    learner_id: str
    class_level: str
    country: str
    stream: Optional[str] = None
    academic_goal: str
    session_size: int = 3


# ---------- Teacher-led autonomous learning sessions ----------
from datetime import datetime, timezone
from app.agents.autonomous_teacher import teacher_step

class TeacherTurnRequest(BaseModel):
    learner_id: str
    message: str = ""
    subject: Optional[str] = None

@app.post("/teacher-agent/turn")
def teacher_agent_turn(req: TeacherTurnRequest, user=Depends(require_role("student"))):
    require_learner_access(req.learner_id, user)
    learner = get_learner(req.learner_id)
    # Upgrade an existing starter-chunk session when structured lessons become
    # available. This changes only the active teaching pointer; mastery,
    # completed topic records, attempts and learning history are retained.
    selected = (req.subject or "").strip()
    if selected:
        available = list_lessons(country=user.country, class_level=user.class_level,
                                 subject=selected, stream=user.stream)
        if available:
            sessions = learner._data.setdefault("teacher_subject_sessions", {})
            state = sessions.get(selected)
            if state is not None:
                old_ids = state.get("lesson_ids") or []
                new_ids = [item["lesson_id"] for item in available]
                if (old_ids and any(str(item).startswith("chunk_") for item in old_ids)
                        and old_ids != new_ids):
                    state["phase"] = "select_lesson"
                    for key in ("lesson_ids", "starter_chunks", "question",
                                "expected_answer", "correct_option", "assessment_kind",
                                "structured_lesson", "structured_questions",
                                "structured_question_index", "assessed_expressions",
                                "_record_current_check"):
                        state.pop(key, None)
                    state["correct_checks"] = 0
                    learner._save()
    return teacher_step(learner, user, req.message, list_lessons, load_lesson, tutor, llm, selected_subject=req.subject)

@app.post("/teacher-agent/extract")
async def teacher_agent_extract(file: UploadFile = File(...), user=Depends(require_role("student"))):
    """Extract text from a learner-supplied document or image; never retain its bytes."""
    content = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds the 20 MB limit")
    try:
        extracted = extract_text_from_upload(content, file.filename or "")
    except OCRUnavailableError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"text": extracted[:8000], "filename": file.filename or "attachment"}

# ---------- Autonomous learning agent endpoints ----------

class AgentPlanActionRequest(BaseModel):
    learner_id: str
    subject: str
    topic: str
    action: Literal["accept", "skip", "complete"]


@app.get("/learner/{learner_id}/agent-state")
def learner_agent_state(learner_id: str, user=Depends(require_role("student"))):
    require_learner_access(learner_id, user)
    learner = get_learner(learner_id)
    plans = list(learner._data.get("agent_plans", {}).values())
    plans.sort(key=lambda p: p.get("updated_at", ""), reverse=True)
    decisions = list(reversed(learner._data.get("agent_decisions", [])[-50:]))
    return {"learner_id": learner_id, "plans": plans, "decisions": decisions}


@app.post("/learner/agent-plan/action")
def update_agent_plan(req: AgentPlanActionRequest, user=Depends(require_role("student"))):
    require_learner_access(req.learner_id, user)
    learner = get_learner(req.learner_id)
    plan = student_action(learner, req.subject, req.topic, req.action)
    if plan is None:
        raise HTTPException(status_code=404, detail="Learning plan not found.")
    return {"plan": plan, "status": plan["status"]}


# ---------- Auth endpoints ----------

@app.post("/auth/signup")
def signup(req: SignupRequest):
    token, user = auth_store.sign_up(
        name=req.name, email=req.email, password=req.password,
        country=req.country, class_level=req.class_level,
        stream=req.stream, academic_goal=req.academic_goal,
    )
    return {"token": token, "user": user.__dict__}


@app.post("/auth/login")
def login(req: LoginRequest):
    token, user = auth_store.log_in(req.email, req.password)
    return {"token": token, "user": user.__dict__}


@app.get("/auth/me")
def me(authorization: Optional[str] = Header(None)):
    user = require_user(authorization)
    return {"user": user.__dict__}


# ---------- Curriculum discovery ----------

@app.get("/countries")
def list_countries():
    return {"countries": retriever.available_countries()}


@app.get("/classes")
def list_classes(country: Optional[str] = None):
    return {"classes": retriever.available_classes(country)}


@app.get("/streams")
def list_streams(country: str, class_level: str):
    return {"streams": retriever.available_streams(country, class_level)}


@app.get("/subjects")
def list_subjects(class_level: str, country: Optional[str] = None, stream: Optional[str] = None):
    return {"subjects": retriever.available_subjects(class_level, country, stream)}


@app.get("/catalogue/subjects")
def nerdc_subject_catalogue(class_level: str, country: str, stream: Optional[str] = None):
    return build_nerdc_subject_response(country, class_level, retriever.chunks, stream)


# ---------- Core tutoring loop ----------

@app.post("/ask")
def ask(req: AskRequest, user=Depends(require_role("student"))):
    require_learner_access(req.learner_id, user)
    learner = get_learner(req.learner_id)
    learner.set_class_level(req.class_level)
    mastery = learner.get_mastery(req.question)
    result = tutor.answer(req.question, req.class_level, req.subject, mastery,
                           country=req.country, stream=req.stream)
    return result


@app.post("/practice/generate")
def practice_generate(req: PracticeGenerateRequest, user=Depends(require_role("student"))):
    require_learner_access(req.learner_id, user)
    result = assessor.generate_question(req.topic, req.class_level, req.subject,
                                         country=req.country, stream=req.stream)
    if not result["question"]:
        raise HTTPException(status_code=404, detail="No curriculum content found for this topic.")
    return result


@app.post("/practice/submit")
def practice_submit(req: PracticeSubmitRequest, user=Depends(require_role("student"))):
    require_learner_access(req.learner_id, user)
    result = assessor.score_answer(req.question, req.student_answer, req.source_chunk_ids, retriever)
    learner = get_learner(req.learner_id)
    new_mastery = (learner.update_subject_mastery(req.subject, req.topic, result["correct"])
                   if req.subject else learner.update_mastery(req.topic, result["correct"]))
    agent_plan = decide_after_assessment(learner, req.subject, req.topic, result["correct"], new_mastery)
    return {**result, "new_mastery": new_mastery, "agent_plan": agent_plan}


@app.get("/learner/{learner_id}/subject-progress")
def learner_subject_progress(learner_id: str, user=Depends(require_role("student"))):
    require_learner_access(learner_id, user)
    available = retriever.available_subjects(user.class_level, user.country, user.stream)
    # The NERDC catalogue can include subjects with content still pending.
    if user.country == 'Nigeria':
        try:
            catalogue = build_nerdc_subject_response(user.country, user.class_level, retriever.chunks, user.stream)
            available = sorted(set(available + [x['name'] for x in catalogue.get('subjects', [])]))
        except Exception:
            pass
    return get_learner(learner_id).subject_progress(available)


_objective_questions = {}
_objective_lock = Lock()


@app.post('/practice/objective/generate')
def objective_generate(req: PracticeGenerateRequest, user=Depends(require_role('student'))):
    require_learner_access(req.learner_id, user)
    chunks = retriever.retrieve(query=req.topic, class_level=req.class_level, subject=req.subject,
                                country=req.country, stream=req.stream, top_k=2)
    if not chunks:
        raise HTTPException(status_code=404, detail='No verified curriculum material for this topic yet.')
    context = '\n'.join(c.text for c in chunks)
    prompt = ('Using ONLY the following curriculum, create ONE multiple-choice question about '+req.topic+
              '. Respond as a JSON object with keys question, options (an array of exactly four short answer strings), '
              'correct_index (integer 0-3), explanation (one short sentence). No markdown.\nCurriculum:\n'+context)
    # Small local models frequently wrap JSON in prose or omit required fields.
    # Recover JSON where possible, otherwise use a deterministic, curriculum-grounded
    # question so offline practice remains usable even if Ollama formatting fails.
    from app.objective_questions import parse_or_fallback
    try:
        raw = llm.generate(prompt, max_tokens=500)
    except (ConnectionError, TimeoutError, ValueError, RuntimeError):
        raw = ''
    data = parse_or_fallback(raw, chunks, req.topic)
    options = data['options']
    correct = data['correct_index']
    question_id = uuid.uuid4().hex
    with _objective_lock:
        if len(_objective_questions)>500:
            _objective_questions.clear()
        _objective_questions[question_id] = {'learner_id': req.learner_id, 'subject': req.subject,
             'topic': req.topic, 'correct': 'ABCD'[correct], 'explanation': str(data.get('explanation','')), 'question':str(data['question'])}
    return {'question_id': question_id, 'question': str(data['question']),
            'options': [{'label':'ABCD'[i],'text':str(option)} for i,option in enumerate(options)],
            'topic':req.topic, 'subject':req.subject}


@app.post('/practice/objective/submit')
def objective_submit(req: ObjectiveSubmitRequest, user=Depends(require_role('student'))):
    require_learner_access(req.learner_id, user)
    with _objective_lock:
        item = _objective_questions.get(req.question_id)
        if not item or item['learner_id'] != req.learner_id:
            raise HTTPException(status_code=404, detail='Question expired. Generate another question.')
        _objective_questions.pop(req.question_id, None)
    correct = req.answer.upper().strip() == item['correct']
    learner = get_learner(req.learner_id)
    mastery = learner.update_subject_mastery(item['subject'],item['topic'],correct)
    agent_plan = decide_after_assessment(learner, item['subject'], item['topic'], correct, mastery)
    return {'correct':correct, 'correct_answer':item['correct'],
            'feedback':item['explanation'] + (' Correct option: '+item['correct']+'.' if not correct else ''),
            'new_mastery':mastery, 'subject':item['subject'], 'topic':item['topic'], 'agent_plan':agent_plan}


class StudyActivityRequest(BaseModel):
    learner_id: str
    subject: str
    topic: str
    kind: Literal['lesson', 'tutor'] = 'lesson'


@app.post('/learner/activity/study')
def record_study(req: StudyActivityRequest, user=Depends(require_role('student'))):
    require_learner_access(req.learner_id, user)
    get_learner(req.learner_id).record_study(req.subject, req.topic, req.kind)
    return {'recorded': True}


@app.get('/learner/{learner_id}/activity')
def learner_activity(learner_id: str, user=Depends(require_role('student'))):
    require_learner_access(learner_id, user)
    return get_learner(learner_id).activity_summary()


@app.get("/learner/{learner_id}/summary")
def learner_summary(learner_id: str, user=Depends(require_role("student"))):
    require_learner_access(learner_id, user)
    learner = get_learner(learner_id)
    return learner.summary()


@app.get("/learner/{learner_id}/topics")
def learner_topics(learner_id: str, subject: str, user=Depends(require_role("student"))):
    require_learner_access(learner_id, user)
    topics = retriever.available_topics(
        class_level=user.class_level,
        subject=subject,
        country=user.country,
        stream=user.stream,
    )
    learner_path = os.path.join(LEARNERS_DIR, f"{learner_id}.json")
    mastery = {}
    if os.path.isfile(learner_path):
        with open(learner_path, "r", encoding="utf-8") as learner_file:
            mastery = json.load(learner_file).get("mastery", {})
    topics.sort(key=lambda topic: mastery.get(topic, 0.3))
    return {
        "country": user.country,
        "class_level": user.class_level,
        "subject": subject,
        "stream": user.stream,
        "topics": [
            {
                "name": topic,
                "mastery": mastery[topic] if topic in mastery else None,
                "progress_status": "recorded" if topic in mastery else "not_started",
            }
            for topic in topics
        ],
    }


@app.get("/learner/{learner_id}/lessons")
def learner_lessons(learner_id: str, subject: str, user=Depends(require_role("student"))):
    require_learner_access(learner_id, user)
    return {"subject": subject, "lessons": list_lessons(
        country=user.country, class_level=user.class_level,
        subject=subject, stream=user.stream,
    )}


@app.get("/learner/{learner_id}/lessons/{lesson_id}")
def learner_lesson(learner_id: str, lesson_id: str, user=Depends(require_role("student"))):
    require_learner_access(learner_id, user)
    try:
        lesson = load_lesson(
            lesson_id,
            country=user.country,
            class_level=user.class_level,
            stream=user.stream,
        )
    except LessonUnavailableError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return lesson.model_dump(mode="json")


# ---------- Planner agent ----------

@app.post("/session-plan")
def session_plan(req: SessionPlanRequest, user=Depends(require_role("student"))):
    require_learner_access(req.learner_id, user)
    learner = get_learner(req.learner_id)
    return planner.build_session_plan(
        learner=learner,
        class_level=req.class_level,
        country=req.country,
        academic_goal=req.academic_goal,
        stream=req.stream,
        session_size=req.session_size,
    )


# ---------- Teacher-facing class overview ----------
# NOTE (honest limitation): there is no teacher role or teacher-specific
# authentication in this prototype. This endpoint is open to anyone who
# knows the URL. A real deployment needs a proper teacher/admin role gate
# here -- see README for how this maps back to the full architecture's
# auth requirements.

@app.get("/teacher/overview")
def teacher_overview(country: str, class_level: str, stream: Optional[str] = None, user=Depends(require_role("teacher"))):
    users = auth_store.list_users(country=country, class_level=class_level, stream=stream)
    users_with_learners = [(u, get_learner(u.id)) for u in users]
    return build_class_overview(users_with_learners)



@app.get("/parent/children")
def parent_children(user=Depends(require_role("parent"))):
    children = auth_store.linked_students(user.id)
    return {"children": [{"id": c.id, "name": c.name, "country": c.country,
             "class_level": c.class_level, "stream": c.stream,
             "summary": get_learner(c.id).summary()} for c in children]}

# ---------- OCR (photo/file upload) ----------

@app.post("/ocr/extract")
async def ocr_extract(file: UploadFile = File(...)):
    # Limit the read itself so oversized uploads are rejected without buffering them fully.
    upload_bytes = await file.read(MAX_UPLOAD_BYTES + 1)
    try:
        text = extract_text_from_upload(upload_bytes, file.filename or "")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    if not text:
        return {"text": "", "warning": "No readable text was found in this file. Try a clearer scan or document."}
    return {"text": text}


# ---------- Health / diagnostics ----------

@app.get("/health")
def health():
    """One place to see what is and isn't working: server version, whether
    the OCR engine was found, and whether Ollama is running with the
    model downloaded. Open http://localhost:8000/health in a browser."""
    return {
        "status": "ok",
        "version": APP_VERSION,
        "ocr": tesseract_status(),
        "llm": llm.status(),
    }
