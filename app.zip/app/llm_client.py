"""
LLM client for the tutor/assessment agents.

Talks to a locally-running Ollama server (default http://localhost:11434).
This is what makes the whole system run with zero API key and zero
per-token cost -- Ollama serves an open-weight model (e.g. llama3.2)
entirely on your own machine.

Setup (one-time, on your own machine, NOT inside this sandbox):
    1. Install Ollama: https://ollama.com/download
    2. Pull a small model:   ollama pull llama3.2:1b
       (or a slightly larger one if your machine can handle it:
        ollama pull llama3.2:3b)
    3. Ollama runs automatically as a local server on port 11434.

If Ollama is not running, LLMClient.generate() raises a clear
ConnectionError rather than failing silently, so it's obvious in
testing/demo whether the LLM backend is actually reachable.
"""

import requests

OLLAMA_URL = "http://localhost:11434/api/generate"
DEFAULT_MODEL = "llama3.2:1b"


class LLMClient:
    def __init__(self, model: str = DEFAULT_MODEL, base_url: str = OLLAMA_URL):
        self.model = model
        self.base_url = base_url

    def generate(self, prompt: str, max_tokens: int = 400) -> str:
        try:
            resp = requests.post(
                self.base_url,
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {"num_predict": max_tokens},
                },
                timeout=60,
            )
            resp.raise_for_status()
        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(
                "Could not reach Ollama at "
                f"{self.base_url}. Is Ollama installed and running? "
                "See app/llm_client.py docstring for setup steps."
            ) from e

        data = resp.json()
        return data.get("response", "").strip()

    def status(self, timeout: float = 1.5) -> dict:
        """Quick, non-generating health check used by /health: is Ollama
        running, and has the configured model actually been downloaded?
        ('Ollama is running but the model was never pulled' is a common
        reason for a tutor that never answers.)"""
        root = self.base_url.split("/api/")[0]
        try:
            resp = requests.get(f"{root}/api/tags", timeout=timeout)
            resp.raise_for_status()
            names = [m.get("name", "") for m in resp.json().get("models", [])]
            return {"reachable": True, "model": self.model,
                    "model_installed": self.model in names}
        except requests.RequestException:
            return {"reachable": False, "model": self.model, "model_installed": None}
