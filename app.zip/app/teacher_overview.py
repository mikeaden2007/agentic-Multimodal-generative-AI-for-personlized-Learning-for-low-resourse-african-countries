"""
Teacher-facing class overview.

Combines each student's account info (from AuthStore) with their mastery
and interaction history (from LearnerModel) into a single summary row,
and computes two flags a teacher can act on:

  - "stuck": the student has made several attempts at a topic (3+) but
    mastery is still low (<0.4) -- this distinguishes a genuinely
    struggling student from one who simply hasn't started that topic yet.
  - "inactive": the student has never interacted with the system, or
    their most recent interaction is older than INACTIVE_DAYS.

This module contains pure, directly testable logic (no FastAPI, no
network) so the flag computation can be verified without needing a
running server or a browser -- consistent with the auditability
principle used throughout the rest of this codebase.
"""

from datetime import datetime, timezone, timedelta
from collections import Counter

STUCK_MASTERY_THRESHOLD = 0.4
STUCK_MIN_ATTEMPTS = 3
INACTIVE_DAYS = 7


def compute_flags(mastery: dict, history: list[dict]) -> list[str]:
    flags = []

    attempts_per_topic = Counter(h["topic"] for h in history)
    for topic, score in mastery.items():
        if score < STUCK_MASTERY_THRESHOLD and attempts_per_topic.get(topic, 0) >= STUCK_MIN_ATTEMPTS:
            flags.append(f"stuck on {topic}")

    if not history:
        flags.append("inactive (no activity yet)")
    else:
        last_ts = max(datetime.fromisoformat(h["timestamp"]) for h in history)
        if datetime.now(timezone.utc) - last_ts > timedelta(days=INACTIVE_DAYS):
            flags.append(f"inactive (no activity in over {INACTIVE_DAYS} days)")

    return flags


def build_class_overview(users_with_learners: list[tuple]) -> dict:
    """
    users_with_learners: list of (User, LearnerModel) tuples, already
    filtered to the class/country/stream a teacher is viewing.

    Returns a summary-first structure: aggregate stats first, then the
    per-student drill-down list -- matching the architecture's low-
    bandwidth "summary-first, drill-down-on-demand" requirement for the
    teacher dashboard, so a teacher on a slow connection sees the
    headline numbers before any per-student detail loads.
    """
    students = []
    for user, learner in users_with_learners:
        summary = learner.summary()
        flags = compute_flags(summary["mastery"], learner._data["history"])
        avg_mastery = (
            sum(summary["mastery"].values()) / len(summary["mastery"])
            if summary["mastery"] else 0.0
        )
        students.append({
            "learner_id": user.id,
            "name": user.name,
            "academic_goal": user.academic_goal,
            "mastery": summary["mastery"],
            "average_mastery": round(avg_mastery, 3),
            "num_interactions": summary["num_interactions"],
            "flags": flags,
        })

    total = len(students)
    flagged_count = sum(1 for s in students if s["flags"])
    class_avg_mastery = (
        round(sum(s["average_mastery"] for s in students) / total, 3) if total else 0.0
    )

    return {
        "summary": {
            "total_students": total,
            "flagged_students": flagged_count,
            "class_average_mastery": class_avg_mastery,
        },
        "students": sorted(students, key=lambda s: len(s["flags"]), reverse=True),
    }
