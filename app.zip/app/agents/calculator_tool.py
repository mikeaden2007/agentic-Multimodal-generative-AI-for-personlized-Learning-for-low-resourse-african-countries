"""
Calculator tool.

Addresses two concrete gaps raised during testing:

1. The tutor could not reliably solve novel arithmetic/algebra problems
   (small local LLMs are unreliable at arithmetic). This module computes
   a REAL, verified result using sympy (safe parsing, not eval()).

2. A verified final answer explained in a paragraph of prose is NOT how
   mathematics is actually taught -- a teacher shows working, step by
   step, the way it would appear on a board. This module therefore also
   generates genuine, correct step-by-step working for the cases it
   supports (linear equations, two-term fraction addition/subtraction,
   percentages, small integer exponents), computed directly from the
   verified numbers -- not narrated by the LLM, which could introduce
   errors or invent steps that don't actually lead to the answer.

Where a dedicated step-by-step generator isn't available for a more
complex expression, this still returns a correct final result, with a
minimal two-line "steps" (question -> answer) rather than fabricating
detailed working it cannot verify.
"""

import re
from dataclasses import dataclass, field
from typing import Optional

import sympy
from sympy import symbols, Eq, solve, Poly, Rational, gcd, lcm
from sympy import log as sympy_log
from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application


@dataclass
class CalculationResult:
    is_computable: bool
    kind: Optional[str] = None          # "evaluate" | "solve"
    input_expression: Optional[str] = None
    result: Optional[str] = None
    steps: list = field(default_factory=list)   # board-style working, one line per step
    error: Optional[str] = None


_TRANSFORMATIONS = standard_transformations + (implicit_multiplication_application,)

_SAFE_NAMES = {
    "log": sympy_log, "ln": sympy.log, "sqrt": sympy.sqrt,
    "sin": sympy.sin, "cos": sympy.cos, "tan": sympy.tan,
    "pi": sympy.pi, "e": sympy.E,
}

_LEADING_PHRASES = re.compile(
    r"^(what\s+is|what's|calculate|evaluate|solve|find|compute|work\s+out)\s+",
    re.IGNORECASE,
)

_TWO_FRACTION_PATTERN = re.compile(
    r"^\s*(-?\d+)\s*/\s*(\d+)\s*([+\-])\s*(-?\d+)\s*/\s*(\d+)\s*$"
)

_PERCENT_OF_PATTERN = re.compile(
    r"(\d+(?:\.\d+)?)\s*%\s*of\s*(\d+(?:\.\d+)?)", re.IGNORECASE
)

_SIMPLE_POWER_PATTERN = re.compile(r"^\s*(-?\d+)\s*\*\*\s*(\d+)\s*$")


def _clean_expression_text(text: str) -> str:
    t = text.strip()
    t = _LEADING_PHRASES.sub("", t).strip()
    t = t.replace("^", "**")
    t = re.sub(r"[?？]\s*$", "", t).strip()
    return t


def _looks_like_equation(text: str) -> bool:
    return "=" in text and bool(re.search(r"[a-zA-Z]", text))


def solve_math(question: str) -> CalculationResult:
    cleaned = _clean_expression_text(question)

    if not re.search(r"\d", cleaned):
        return CalculationResult(is_computable=False)

    if _looks_like_equation(cleaned):
        return _solve_equation(cleaned)
    return _evaluate_expression(cleaned)


# ---------- Expression evaluation, with dedicated step generators ----------

def _evaluate_expression(expr_text: str) -> CalculationResult:
    # Try dedicated, pedagogically-correct step generators first, in
    # order of specificity, before falling back to a generic evaluation.
    percent_match = _PERCENT_OF_PATTERN.search(expr_text)
    if percent_match and expr_text.strip().lower().startswith(percent_match.group(0).lower()):
        return _evaluate_percentage(percent_match, expr_text)

    fraction_match = _TWO_FRACTION_PATTERN.match(expr_text)
    if fraction_match:
        return _evaluate_two_fraction_sum(fraction_match, expr_text)

    normalized = expr_text.replace(" ", "")
    power_match = _SIMPLE_POWER_PATTERN.match(normalized)
    if power_match:
        return _evaluate_small_power(power_match, expr_text)

    return _evaluate_generic(expr_text)


def _evaluate_percentage(match, expr_text: str) -> CalculationResult:
    try:
        pct, of = Rational(match.group(1)), Rational(match.group(2))
        fraction = pct / 100
        result = fraction * of
        steps = [
            f"{pct}% of {of}",
            f"= ({pct}/100) \u00d7 {of}",
            f"= {fraction} \u00d7 {of}",
            f"= {result}",
        ]
        return CalculationResult(is_computable=True, kind="evaluate", input_expression=expr_text,
                                  result=str(result), steps=steps)
    except Exception:
        return CalculationResult(is_computable=False)


def _evaluate_two_fraction_sum(match, expr_text: str) -> CalculationResult:
    try:
        n1, d1, op, n2, d2 = match.groups()
        n1, d1, n2, d2 = int(n1), int(d1), int(n2), int(d2)
        common = lcm(d1, d2)
        n1_conv = n1 * (common // d1)
        n2_conv = n2 * (common // d2)
        combined_n = n1_conv + n2_conv if op == "+" else n1_conv - n2_conv
        result = Rational(combined_n, common)

        steps = [f"{n1}/{d1} {op} {n2}/{d2}"]
        if d1 != common or d2 != common:
            steps.append(
                f"Find a common denominator: {d1} and {d2} \u2192 {common}"
            )
            steps.append(f"= {n1_conv}/{common} {op} {n2_conv}/{common}")
        steps.append(f"= {combined_n}/{common}")
        if result.q != common or (common % result.q == 0 and common != abs(result.q)):
            if str(result) != f"{combined_n}/{common}":
                steps.append(f"= {result}  (simplified)")

        return CalculationResult(is_computable=True, kind="evaluate", input_expression=expr_text,
                                  result=str(result), steps=steps)
    except Exception:
        return CalculationResult(is_computable=False)


def _evaluate_small_power(match, expr_text: str) -> CalculationResult:
    try:
        base, exp = int(match.group(1)), int(match.group(2))
        result = base ** exp
        if 0 < exp <= 6:
            factors = " \u00d7 ".join([str(base)] * exp)
            steps = [f"{base}^{exp}", f"= {factors}", f"= {result}"]
        else:
            steps = [f"{base}^{exp}", f"= {result}"]
        return CalculationResult(is_computable=True, kind="evaluate", input_expression=expr_text,
                                  result=str(result), steps=steps)
    except Exception:
        return CalculationResult(is_computable=False)


def _evaluate_generic(expr_text: str) -> CalculationResult:
    try:
        expr = parse_expr(expr_text, transformations=_TRANSFORMATIONS, local_dict=_SAFE_NAMES)
        if not expr.free_symbols and expr.is_number is False:
            return CalculationResult(is_computable=False)
        simplified = sympy.simplify(sympy.nsimplify(expr))
        display = str(simplified) if simplified.is_rational else str(sympy.N(simplified, 6))
        return CalculationResult(
            is_computable=True, kind="evaluate", input_expression=expr_text,
            result=display, steps=[expr_text, f"= {display}"],
        )
    except Exception:
        return CalculationResult(is_computable=False)


# ---------- Equation solving, with a dedicated linear step generator ----------

def _solve_equation(expr_text: str) -> CalculationResult:
    try:
        lhs_text, rhs_text = expr_text.split("=", 1)
        lhs_text, rhs_text = lhs_text.strip(), rhs_text.strip()

        alpha_runs = set(re.findall(r"[a-zA-Z]+", expr_text))
        var_names = sorted(name for name in alpha_runs if name.lower() not in _SAFE_NAMES)
        if len(var_names) != 1 or len(var_names[0]) != 1:
            return CalculationResult(is_computable=False)
        varname = var_names[0]
        var = symbols(varname)
        local = {**_SAFE_NAMES, varname: var}

        lhs = parse_expr(lhs_text, transformations=_TRANSFORMATIONS, local_dict=local)
        rhs = parse_expr(rhs_text, transformations=_TRANSFORMATIONS, local_dict=local)
        solutions = solve(Eq(lhs, rhs), var)
        if not solutions:
            return CalculationResult(is_computable=False)

        result_display = ", ".join(f"{varname} = {s}" for s in solutions)
        steps = _linear_equation_steps(lhs, rhs, var, varname, lhs_text, rhs_text, solutions)

        return CalculationResult(is_computable=True, kind="solve", input_expression=expr_text,
                                  result=result_display, steps=steps)
    except Exception:
        return CalculationResult(is_computable=False)


def _format_term(coef, varname: str) -> str:
    if coef == 1:
        return varname
    if coef == -1:
        return f"-{varname}"
    return f"{coef}{varname}"


def _linear_equation_steps(lhs, rhs, var, varname, lhs_text, rhs_text, solutions) -> list:
    """Generate genuine, verified step-by-step working for the common
    textbook pattern: a linear expression in the variable on the LEFT,
    a plain number (no variable) on the RIGHT -- e.g. '2x + 5 = 15'.

    Deliberately scoped to this pattern only: the narrative ("subtract
    5 from both sides") must be built from the ORIGINAL left-hand side's
    own coefficient and constant, not from an internally-combined
    lhs-minus-rhs expression -- conflating the two produces a
    mathematically-wrong-sounding narrative even though the final
    answer would still be correct. Anything outside this pattern (e.g.
    the variable appearing on both sides) falls back to a minimal,
    still-100%-correct [original, answer] display rather than fabricate
    a narrative this function can't verify.
    """
    if rhs.free_symbols:  # variable also appears on the right -- not the simple pattern
        return [f"{lhs_text} = {rhs_text}", f"{varname} = {solutions[0]}"]

    try:
        lhs_poly = Poly(lhs, var)
        if lhs_poly.degree() != 1:
            raise ValueError("left-hand side is not linear in the variable")
        A, lhs_constant = lhs_poly.all_coeffs()
    except Exception:
        return [f"{lhs_text} = {rhs_text}", f"{varname} = {solutions[0]}"]

    rhs_value = sympy.simplify(rhs)
    moved_rhs = rhs_value - lhs_constant

    steps = [f"{lhs_text} = {rhs_text}"]

    if lhs_constant != 0:
        verb = "Subtract" if lhs_constant > 0 else "Add"
        amount = abs(lhs_constant)
        steps.append(f"{verb} {amount} {'from' if verb == 'Subtract' else 'to'} both sides: "
                      f"{_format_term(A, varname)} = {moved_rhs}")
    else:
        steps.append(f"{_format_term(A, varname)} = {moved_rhs}")

    if A != 1:
        steps.append(f"Divide both sides by {A}: {varname} = {moved_rhs}/{A}")

    steps.append(f"{varname} = {solutions[0]}")
    return steps
