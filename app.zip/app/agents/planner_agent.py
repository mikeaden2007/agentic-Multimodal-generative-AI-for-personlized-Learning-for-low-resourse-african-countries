"""
Planner agent.

Decomposes a learner's overall academic goal into a concrete session plan:
an ordered list of (subject, topic) steps to work on today, each tagged
with a recommended activity (learn / practice / review) based on the
learner's current mastery of that topic.

Design principle, consistent with the paper's auditability requirement:
the DECISION of what to study and in what order is fully deterministic
and computed from data already in the system (curriculum topics +
learner mastery) -- not delegated to the LLM. This makes the plan
traceable and reproducible: given the same mastery state, the same plan
is always produced, and that plan does not depend on the LLM being
reachable at all (it works with Ollama offline). The LLM is used only,
optionally, to phrase a short, friendly introduction to the ALREADY-
DECIDED plan -- it is explicitly instructed not to introduce topics
beyond the ones the planner selected, and if the LLM is unreachable the
plan is still returned in full, with a simple templated introduction
instead. Planning capability does not depend on LLM availability.
"""

from dataclasses import dataclass
from typing import Optional

from app.rag.retriever import CurriculumRetriever
from app.learner_model import LearnerModel
from app.llm_client import LLMClient

LEARN_THRESHOLD = 0.4     # below this: learner likely hasn't grasped the topic yet
REVIEW_THRESHOLD = 0.7    # above this: topic is in good shape, light review only


@dataclass
class PlanStep:
    subject: str
    topic: str
    mastery: float
    activity: str  # "learn" | "practice" | "review"


def _activity_for(mastery: float) -> str:
    if mastery < LEARN_THRESHOLD:
        return "learn"
    if mastery < REVIEW_THRESHOLD:
        return "practice"
    return "review"


class PlannerAgent:
    def __init__(self, retriever: CurriculumRetriever, llm: LLMClient):
        self.retriever = retriever
        self.llm = llm

    def _all_topics_for_learner(self, class_level: str, country: str,
                                 stream: Optional[str]) -> list[tuple[str, str]]:
        """Every (subject, topic) pair available to this learner, across all
        subjects their class/country/stream gives them access to."""
        pairs = []
        for subject in self.retriever.available_subjects(class_level, country, stream):
            for topic in self.retriever.available_topics(class_level, subject, country, stream):
                pairs.append((subject, topic))
        return pairs

    def build_session_plan(self, learner: LearnerModel, class_level: str, country: str,
                            academic_goal: str, stream: Optional[str] = None,
                            session_size: int = 3) -> dict:
        all_pairs = self._all_topics_for_learner(class_level, country, stream)

        scored = [
            PlanStep(subject=subj, topic=topic, mastery=learner.get_mastery(topic),
                     activity=_activity_for(learner.get_mastery(topic)))
            for subj, topic in all_pairs
        ]
        # Weakest topics first -- this is the entire "planning" decision,
        # and it is fully deterministic and inspectable.
        scored.sort(key=lambda s: s.mastery)
        steps = scored[:session_size]

        intro = self._generate_intro(steps, academic_goal)

        return {
            "intro_message": intro,
            "steps": [
                {"subject": s.subject, "topic": s.topic, "mastery": s.mastery, "activity": s.activity}
                for s in steps
            ],
        }

    def _generate_intro(self, steps: list[PlanStep], academic_goal: str) -> str:
        if not steps:
            return "No curriculum topics are available yet for your class -- ask your teacher to add some."

        topic_list = ", ".join(f"{s.topic} ({s.subject})" for s in steps)
        prompt = f"""A student's academic goal is: "{academic_goal}"

Today's study session has already been planned to cover exactly these topics,
in this order, and no others: {topic_list}

Write one short, encouraging sentence (max 30 words) introducing this session
to the student, connecting it to their stated goal. Do not mention any topic
that is not in the list above. Do not invent new topics."""
        try:
            return self.llm.generate(prompt, max_tokens=80).strip()
        except ConnectionError:
            # Deterministic fallback -- the plan itself does not depend on
            # the LLM being reachable, only this friendly phrasing does.
            return f"Today's session: {topic_list}."
