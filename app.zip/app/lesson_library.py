"""Filesystem-only lesson loader; optional local SS3 Mathematics draft testing."""

import json
import os
from pathlib import Path
from typing import Optional

from pydantic import ValidationError

from app.lesson_schema import Lesson


LESSON_DIRECTORY = Path(__file__).resolve().parent / "data" / "lessons"


def _draft_test_enabled() -> bool:
    """Explicit opt-in; never enabled merely because draft files exist."""
    return os.environ.get("ASKTUTOR_SS3_MATH_DRAFT_TEST", "").strip() == "1"


class LessonUnavailableError(Exception):
    """No reviewed, profile-matching local lesson is available."""


def _lesson_file(root: Path, lesson_id: str) -> Path:
    if not lesson_id or not all(char.isalnum() or char in "_-" for char in lesson_id):
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.")
    root = root.resolve()
    candidate = (root / f"{lesson_id}.json").resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.") from exc
    return candidate


def load_lesson(
    lesson_id: str,
    *,
    country: str,
    class_level: str,
    stream: Optional[str] = None,
    subject: Optional[str] = None,
    lesson_directory: Optional[Path] = None,
) -> Lesson:
    """Load a profile-matching reviewed lesson, or explicitly enabled SS3 Maths draft."""
    root = Path(lesson_directory or LESSON_DIRECTORY).resolve()
    path = _lesson_file(root, lesson_id)
    try:
        path.relative_to(root)
        raw = json.loads(path.read_text(encoding="utf-8"))
        lesson = Lesson.model_validate(raw)
    except (OSError, UnicodeError, json.JSONDecodeError, ValidationError, ValueError) as exc:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.") from exc

    allow_draft = (
        _draft_test_enabled()
        and lesson.country == "Nigeria"
        and lesson.class_level == "SS3"
        and lesson.subject in ("Mathematics", "General Mathematics")
        and lesson.lesson_id.startswith("ss3_math_")
        and lesson.review_status == "draft"
    )
    if lesson.lesson_id != lesson_id or (lesson.review_status != "reviewed" and not allow_draft) or not lesson.source_references:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.")
    if lesson.country != country or lesson.class_level != class_level:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.")
    if lesson.stream is not None and lesson.stream != stream:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.")
    if subject is not None and lesson.subject != subject:
        raise LessonUnavailableError("Verified lesson is unavailable for this learner.")

    for illustration in lesson.illustrations:
        image_path = (root / illustration.path).resolve()
        try:
            image_path.relative_to(root)
        except ValueError as exc:
            raise LessonUnavailableError("Verified lesson is unavailable for this learner.") from exc
        if not image_path.is_file():
            raise LessonUnavailableError("Verified lesson is unavailable for this learner.")

    return lesson

def list_lessons(*, country: str, class_level: str, subject: str, stream: Optional[str] = None, lesson_directory: Optional[Path] = None) -> list[dict]:
    """Discover profile-matching lessons; drafts require explicit test opt-in."""
    root = Path(lesson_directory or LESSON_DIRECTORY).resolve()
    if not root.is_dir():
        return []
    results = []
    for path in sorted(root.glob("*.json")):
        try:
            # load_lesson checks file containment, schema, review status and profile.
            lesson = load_lesson(path.stem, country=country, class_level=class_level,
                                 subject=subject, stream=stream, lesson_directory=root)
        except LessonUnavailableError:
            continue
        results.append({"lesson_id": lesson.lesson_id, "topic": lesson.topic, "subject": lesson.subject})
    order = {"ss3_math_indices_laws": 0, "ss3_math_log_intro": 1,
             "ss3_math_log_laws": 2, "ss3_math_log_characteristic": 3,
             "ss3_math_log_exponential": 4}
    results.sort(key=lambda item: (order.get(item["lesson_id"], 1000), item["lesson_id"]))
    return results
